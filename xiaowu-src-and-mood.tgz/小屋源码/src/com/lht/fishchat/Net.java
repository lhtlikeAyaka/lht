package com.lht.fishchat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Message;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

class Prober implements Runnable {
    final MainActivity a;
    Prober(MainActivity a) { this.a = a; }

    public void run() {
        int myGen = Net.gen;
        String pref = Net.line();
        String pick = Net.tryLine(pref);
        if (pick == null) {
            String other = Net.next(pref);
            if (!other.equals(pref)) pick = Net.tryLine(other);
        }
        if (myGen != Net.gen) return;
        int sgen = -1;
        if (pick != null) {
            Net.BASE = Net.baseOf(pick);
            Net.markOk();
            sgen = Net.fetchGen();
            Net.conn(a, -1, true);
        } else {
            Net.BASE = Net.baseOf(pref);
            Net.conn(a, 0, false);
        }
        Message m = Message.obtain();
        m.what = MainActivity.MSG_BOOT;
        m.arg1 = sgen;
        a.ui.sendMessage(m);
        Message c = Message.obtain();
        c.what = MainActivity.MSG_CHECK;
        a.ui.sendMessageDelayed(c, 3000);
    }
}

class Poster implements Runnable {
    final MainActivity a;
    final String body;
    final String text;
    final android.widget.TextView st;
    final int tmp;
    Poster(MainActivity a, String body, String text, android.widget.TextView st, int tmp) {
        this.a = a; this.body = body; this.text = text; this.st = st; this.tmp = tmp;
    }

    public void run() {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(Net.BASE + "/send").openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                c.setUseCaches(false);
                c.setRequestProperty("Connection", "close");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.flush();
                os.close();
                String s = Net.readAll(c);
                c.disconnect();
                Net.conn(a, -1, true);
                try {
                    JSONObject o = new JSONObject(s);
                    Message m1 = Message.obtain();
                    m1.what = MainActivity.MSG_SENT;
                    m1.arg1 = o.optInt("id", 0);
                    m1.arg2 = tmp;
                    // 把服务端返回的整条记录捎回去：id/ts/state 以它为准
                    m1.obj = new Object[]{st, s};
                    a.ui.sendMessage(m1);
                } catch (Exception parseErr) {
                }
                last = null;
                break;
            } catch (Exception e) {
                last = e;
                if (c != null) c.disconnect();
                Net.status(a, "没送到，" + Net.label() + "不通，看看别的线路…");
                Net.failover(a);
                try { Thread.sleep(600); } catch (InterruptedException ignored) {}
            }
        }
        if (last != null) {
            UpLog.dump(a, last);
            Net.status(a, "没送到：" + UpLog.brief(last));
            Message mf = Message.obtain();
            mf.what = MainActivity.MSG_SEND_FAIL;
            mf.obj = new Object[]{st, text, Integer.valueOf(tmp)};
            a.ui.sendMessage(mf);
        }
        Message m2 = Message.obtain();
        m2.what = MainActivity.MSG_POLL_NOW;
        a.ui.sendMessageDelayed(m2, 600);
    }
}

class Loader implements Runnable {
    final MainActivity a;
    Loader(MainActivity a) { this.a = a; }

    public void run() {
        long t0 = System.currentTimeMillis();
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/recent?n=300").openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(12000);
            c.setRequestProperty("Connection", "close");
            String s = Net.readAll(c);
            c.disconnect();
            Net.conn(a, System.currentTimeMillis() - t0, true);
            Message m = Message.obtain();
            m.what = MainActivity.MSG_BATCH;
            m.obj = s;
            a.ui.sendMessage(m);
        } catch (Exception e) {
            Net.conn(a, 0, false);
            Net.status(a, "历史没拉到，" + Net.label() + "不通");
            Net.failover(a);
        }
        Message m2 = Message.obtain();
        m2.what = MainActivity.MSG_POLL_NOW;
        a.ui.sendMessageDelayed(m2, 500);
    }
}

class Poller implements Runnable {
    final MainActivity a;
    final long since;
    Poller(MainActivity a, long since) { this.a = a; this.since = since; }

    public void run() {
        if (Net.polling) return;
        Net.polling = true;
        try {
            runOnce();
        } finally {
            Net.polling = false;
        }
    }

    void runOnce() {
        boolean ok = false;
        // since 往回退几条：万一之前漏了一条（发送成功把 lastId 顶高、网络抖一下），
        // 下一轮能自己补回来；重复的靠 id 去重，不会重影
        long from = since > 5 ? since - 5 : 0;
        for (int attempt = 0; attempt < 2 && !ok; attempt++) {
            long t0 = System.currentTimeMillis();
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/poll?since=" + from).openConnection();
                c.setConnectTimeout(6000);
                c.setReadTimeout(8000);
                c.setUseCaches(false);
                c.setRequestProperty("Connection", "close");
                String s = Net.readAll(c);
                c.disconnect();
                Net.conn(a, System.currentTimeMillis() - t0, true);
                ok = true;
                JSONArray arr = new JSONArray(s);
                if (arr.length() > 0) {
                    Message m = Message.obtain();
                    m.what = MainActivity.MSG_BATCH;
                    m.obj = s;
                    a.ui.sendMessage(m);
                }
            } catch (Exception e) {
                try { Thread.sleep(600); } catch (InterruptedException ignored) { }
            }
        }
        if (!ok && !Net.uploading) {
            Net.conn(a, 0, false);
            Net.failover(a);
        }
        Message m2 = Message.obtain();
        m2.what = MainActivity.MSG_POLL_NOW;
        a.ui.sendMessageDelayed(m2, ok ? Net.pollMs : Net.retryDelay());
        new Thread(new StatePoller(a)).start();
    }
}

class StatePoller implements Runnable {
    final MainActivity a;
    StatePoller(MainActivity a) { this.a = a; }

    public void run() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/state").openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(5000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            String s = Net.readAll(c);
            c.disconnect();
            Net.conn(a, -1, true);
            JSONObject o = new JSONObject(s);
            JSONArray arr = o.optJSONArray("read_ids");
            java.util.ArrayList<Integer> ids = new java.util.ArrayList<Integer>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) ids.add(Integer.valueOf(arr.optInt(i)));
            }
            Message m = Message.obtain();
            m.what = MainActivity.MSG_STATE;
            m.obj = new Object[]{Boolean.valueOf(o.optBoolean("typing", false)), ids};
            a.ui.sendMessage(m);
            if (o.has("gen")) {
                Message g = Message.obtain();
                g.what = MainActivity.MSG_GEN;
                g.arg1 = o.optInt("gen", -1);
                a.ui.sendMessage(g);
            }
        } catch (Exception ignored) {
        }
    }
}

class BalPoller implements Runnable {
    final MainActivity a;
    BalPoller(MainActivity a) { this.a = a; }

    public void run() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/balance").openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            String s = Net.readAll(c);
            c.disconnect();
            Message m = Message.obtain();
            m.what = MainActivity.MSG_BAL;
            m.obj = s;
            a.ui.sendMessage(m);
        } catch (Exception ignored) {
        }
    }
}

class MoodPoller implements Runnable {
    final MainActivity a;
    MoodPoller(MainActivity a) { this.a = a; }

    public void run() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/mood").openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(5000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            String s = Net.readAll(c);
            c.disconnect();
            Message m = Message.obtain();
            m.what = MainActivity.MSG_MOOD;
            m.obj = s;
            a.ui.sendMessage(m);
        } catch (Exception ignored) {
        }
    }
}

class Uploader implements Runnable {
    static File shrink(MainActivity a, Uri uri, File tmp) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream is = a.getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(is, null, o);
        is.close();
        int big = Math.max(o.outWidth, o.outHeight);
        int sample = 1;
        while (big / sample > 2400) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        InputStream is2 = a.getContentResolver().openInputStream(uri);
        Bitmap bm = BitmapFactory.decodeStream(is2, null, o2);
        is2.close();
        if (bm == null) return tmp;

        long limit = 250 * 1024;
        int[] sides = {1280, 1120, 960};
        int[] quals = {70, 60, 55, 45};
        try {
            for (int si = 0; si < sides.length; si++) {
                int w = bm.getWidth(), h = bm.getHeight();
                int side = Math.max(w, h);
                Bitmap cur = bm;
                if (side > sides[si]) {
                    float k = sides[si] / (float) side;
                    cur = Bitmap.createScaledBitmap(bm, Math.round(w * k), Math.round(h * k), true);
                }
                for (int qi = 0; qi < quals.length; qi++) {
                    FileOutputStream fo = new FileOutputStream(tmp);
                    cur.compress(Bitmap.CompressFormat.JPEG, quals[qi], fo);
                    fo.close();
                    if (tmp.length() <= limit || qi == quals.length - 1 && si == sides.length - 1) {
                        if (cur != bm) cur.recycle();
                        bm.recycle();
                        return tmp;
                    }
                }
                if (cur != bm) cur.recycle();
            }
        } finally {
            if (!bm.isRecycled()) bm.recycle();
        }
        return tmp;
    }

    final MainActivity a;
    final Uri uri;
    final String kind;
    final String name;
    final android.widget.TextView pv;
    Uploader(MainActivity a, Uri uri, String kind, String name, android.widget.TextView pv) {
        this.a = a; this.uri = uri; this.kind = kind; this.name = name; this.pv = pv;
    }

    void pct(int p) {
        if (pv == null) return;
        Message m = Message.obtain();
        m.what = MainActivity.MSG_UP;
        m.obj = new Object[]{pv, Integer.valueOf(p)};
        a.ui.sendMessage(m);
    }

    void fail(Exception e, Uri uri, String kind, String name) {
        if (e != null) UpLog.dump(a, e);
        String msg = UpLog.brief(e);
        Net.status(a, "上传失败：" + msg);
        if (pv != null) {
            Message m = Message.obtain();
            m.what = MainActivity.MSG_UP_FAIL;
            m.obj = new Object[]{pv, uri, kind, name};
            a.ui.sendMessage(m);
        }
    }

    public void run() {
        File tmp = null;
        Net.uploading = true;
        try {
            tmp = File.createTempFile("upl", ".bin", a.getCacheDir());
            byte[] buf = new byte[65536];
            int n;
            if ("image".equals(kind)) {
                shrink(a, uri, tmp);
                if (tmp.length() == 0) throw new Exception("图片读不出来");
                Net.status(a, "压到 " + (tmp.length() / 1024) + " KB，开始传");
            } else {
                InputStream in = a.getContentResolver().openInputStream(uri);
                FileOutputStream fo = new FileOutputStream(tmp);
                while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                in.close();
                fo.close();
                Net.status(a, "准备上传 " + (tmp.length() / 1024) + " KB");
            }
            String q = "?who=" + URLEncoder.encode("老大", "UTF-8")
                    + "&kind=" + URLEncoder.encode(kind, "UTF-8")
                    + "&name=" + URLEncoder.encode(name, "UTF-8");
            String boundary = "----fish" + System.currentTimeMillis();
            String head = "--" + boundary + "\r\n"
                    + "Content-Disposition: form-data; name=\"file\"; filename=\"" + name + "\"\r\n"
                    + "Content-Type: application/octet-stream\r\n\r\n";
            String tail = "\r\n--" + boundary + "--\r\n";
            byte[] hb = head.getBytes("UTF-8");
            byte[] tb = tail.getBytes("UTF-8");
            long total = hb.length + tmp.length() + tb.length;

            Exception last = null;
            for (int attempt = 0; attempt < 2; attempt++) {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(Net.BASE + "/upload" + q).openConnection();
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setConnectTimeout(12000);
                    c.setReadTimeout(240000);
                    c.setRequestProperty("Connection", "close");
                    c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                    if (attempt == 0) c.setFixedLengthStreamingMode((int) total);
                    else c.setChunkedStreamingMode(65536);
                    OutputStream os = c.getOutputStream();
                    long sent = 0;
                    long lastSent = 0;
                    long lastMs = System.currentTimeMillis();
                    os.write(hb);
                    sent += hb.length;
                    InputStream fi = new java.io.FileInputStream(tmp);
                    while ((n = fi.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        sent += n;
                        long now = System.currentTimeMillis();
                        if (sent - lastSent >= 256 * 1024 || now - lastMs >= 100) {
                            lastSent = sent;
                            lastMs = now;
                            int p = (int) (sent * 100 / (total > 0 ? total : 1));
                            if (p > 99) p = 99;
                            pct(p);
                        }
                    }
                    fi.close();
                    os.write(tb);
                    os.flush();
                    os.close();
                    pct(100);
                    String s = Net.readAll(c);
                    c.disconnect();
                    if (s.indexOf("\"err\"") >= 0) throw new Exception("服务端没收全：" + s);
                    try {
                        JSONObject jo = new JSONObject(s);
                        String u = jo.optString("url", "");
                        if (u.length() > 0) {
                            File cf = Net.imgCache(a, u);
                            java.io.FileInputStream ci = new java.io.FileInputStream(tmp);
                            FileOutputStream co = new FileOutputStream(cf);
                            while ((n = ci.read(buf)) > 0) co.write(buf, 0, n);
                            co.flush();
                            co.close();
                            ci.close();
                        }
                    } catch (Exception ignored) {
                    }
                    Net.status(a, "已发出");
                    Message m = Message.obtain();
                    m.what = MainActivity.MSG_UP_DONE;
                    m.obj = new Object[]{pv, s};
                    a.ui.sendMessage(m);
                    return;
                } catch (Exception e) {
                    last = e;
                    if (c != null) c.disconnect();
                    Net.status(a, "第 " + (attempt + 1) + " 次上传失败，" + Net.label() + "不通");
                    if (attempt == 0) Net.failover(a);
                    try { Thread.sleep(700); } catch (InterruptedException ignored) {}
                }
            }
            fail(last, uri, kind, name);
        } catch (Exception e) {
            fail(e, uri, kind, name);
        } finally {
            Net.uploading = false;
            if (tmp != null) tmp.delete();
        }
    }
}

class UpLog {
    static String brief(Throwable e) {
        if (e == null) return "未知错误";
        StringBuilder sb = new StringBuilder();
        sb.append(e.getClass().getName()).append(": ").append(e.getMessage());
        StackTraceElement[] st = e.getStackTrace();
        for (int i = 0; i < st.length && i < 3; i++) sb.append("\n  at ").append(st[i].toString());
        return sb.toString();
    }

    static void dump(MainActivity a, Throwable e) {
        try {
            String stamp = new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(new java.util.Date());
            String line = "[" + stamp + "] " + brief(e) + "\n";
            File dir = null;
            try { dir = a.getExternalFilesDir(null); } catch (Exception ignored) {}
            if (dir == null) dir = a.getFilesDir();
            File f = new File(dir, "upload_err.txt");
            FileOutputStream fo = new FileOutputStream(f, true);
            fo.write(line.getBytes("UTF-8"));
            fo.close();
        } catch (Exception ignored) {}
    }
}

class ImageLoader implements Runnable {
    final MainActivity a;
    final android.widget.ImageView iv;
    final String url;
    ImageLoader(MainActivity a, android.widget.ImageView iv, String url) {
        this.a = a; this.iv = iv; this.url = url;
    }

    static Bitmap decodeSafe(File f) {
        try {
            Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (bm != null && bm.getWidth() > 1 && bm.getHeight() > 1) return bm;
        } catch (Exception ignored) {
        }
        return null;
    }

    public void run() {
        Bitmap bm = null;
        String src = url;
        int cut = src.indexOf("/files/");
        if (cut > 0) src = Net.BASE + src.substring(cut);
        File dir = new File(a.getCacheDir(), "img");
        if (!dir.exists()) dir.mkdirs();
        String tag = Net.imgKey(url);
        File f = new File(dir, tag);
        File part = new File(dir, tag + ".part");
        if (f.exists() && f.length() > 0) bm = decodeSafe(f);
        for (int attempt = 0; attempt < 2 && bm == null; attempt++) {
            if (attempt > 0) {
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
            }
            f.delete();
            InputStream in = null;
            FileOutputStream out = null;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(src).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(60000);
                c.setUseCaches(false);
                c.setRequestProperty("Connection", "close");
                int expect = c.getContentLength();
                in = c.getInputStream();
                out = new FileOutputStream(part);
                byte[] buf = new byte[16384];
                int n;
                long got = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    got += n;
                }
                out.flush();
                out.close();
                out = null;
                in.close();
                in = null;
                c.disconnect();
                if (expect > 0 && got != expect) {
                    throw new Exception("图片只收到 " + got + "/" + expect + " 字节");
                }
                Net.conn(a, -1, true);
                if (part.renameTo(f)) bm = decodeSafe(f);
            } catch (Exception e) {
                UpLog.dump(a, e);
                try { if (out != null) out.close(); } catch (Exception ignored) {}
                try { if (in != null) in.close(); } catch (Exception ignored) {}
            }
            part.delete();
            if (bm == null) f.delete();
        }
        Message m = Message.obtain();
        m.what = MainActivity.MSG_BITMAP;
        m.obj = new Object[]{iv, bm, url};
        a.ui.sendMessage(m);
    }
}

class Net {
    static volatile String BASE = "https://napcat.994528.xyz";
    static volatile int gen = 0;
    static final String LAN = "http://192.168.110.5:6099";
    static final String WAN = "https://napcat.994528.xyz";
    static final String FRP = "";
    static volatile int pollMs = 3000;
    static volatile boolean uploading = false;
    static volatile boolean polling = false;

    static android.content.Context ctx = null;
    static volatile long lastOkAt = 0;
    static volatile int failCount = 0;
    static volatile long nextTryAt = 0;
    static volatile int backoffMs = 0;

    static android.content.SharedPreferences prefs() {
        return ctx.getSharedPreferences("fishchat", android.content.Context.MODE_PRIVATE);
    }

    static boolean hasFrp() { return FRP != null && FRP.length() > 0; }

    static String baseOf(String name) {
        if ("wan".equals(name)) return WAN;
        if ("frp".equals(name)) return hasFrp() ? FRP : LAN;
        return LAN;
    }

    static String nameOf(String base) {
        if (WAN.equals(base)) return "wan";
        if (hasFrp() && FRP.equals(base)) return "frp";
        return "lan";
    }

    static String next(String cur) {
        if ("lan".equals(cur)) return "wan";
        if ("wan".equals(cur)) return hasFrp() ? "frp" : "lan";
        return "lan";
    }

    static String label(String name) {
        if ("wan".equals(name)) return "外网";
        if ("frp".equals(name)) return "frp";
        return "内网";
    }

    static String label() {
        return label(nameOf(BASE));
    }

    static String line() {
        String n = "lan";
        try {
            n = prefs().getString("net", "lan");
        } catch (Exception ignored) {
        }
        if ("frp".equals(n) && !hasFrp()) n = "lan";
        if (!"wan".equals(n) && !"frp".equals(n)) n = "lan";
        return n;
    }

    static String tryLine(String name) {
        String base = baseOf(name);
        int ms = LAN.equals(base) ? 1300 : 2500;
        return reachable(base, ms) ? name : null;
    }

    static int fetchGen() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/state").openConnection();
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            String s = readAll(c);
            c.disconnect();
            return new JSONObject(s).optInt("gen", -1);
        } catch (Exception e) {
            return -1;
        }
    }

    static void markOk() {
        lastOkAt = System.currentTimeMillis();
        failCount = 0;
        backoffMs = 0;
        nextTryAt = 0;
        try {
            String n = nameOf(BASE);
            if (!n.equals(prefs().getString("net", "lan"))) {
                prefs().edit().putString("net", n).apply();
            }
        } catch (Exception ignored) {
        }
    }

    static int backoffFor(int n) {
        if (n <= 1) return 2000;
        if (n == 2) return 4000;
        if (n == 3) return 8000;
        if (n == 4) return 16000;
        return 30000;
    }

    static long retryDelay() {
        int n = failCount;
        if (n <= 1) return 6000;
        if (n == 2) return 12000;
        if (n == 3) return 20000;
        return 30000;
    }

    // 自动换线已关：在外面外网断了切内网纯属徒劳，改由状态条手动切。
    static final boolean AUTO_SWITCH = false;

    static synchronized boolean failover(MainActivity a) {
        if (!AUTO_SWITCH) return false;
        long now = System.currentTimeMillis();
        if (now < nextTryAt) return false;
        nextTryAt = now + 3000;
        String cur = nameOf(BASE);
        String other = next(cur);
        if (other.equals(cur)) {
            nextTryAt = now + 30000;
            return false;
        }
        int probeMs = LAN.equals(baseOf(other)) ? 1300 : 2500;
        boolean ok = reachable(baseOf(other), probeMs);
        if (ok) {
            BASE = baseOf(other);
            failCount = 0;
            backoffMs = 0;
            nextTryAt = 0;
            try {
                prefs().edit().putString("net", other).apply();
            } catch (Exception ignored) {
            }
            if (a != null) {
                conn(a, -1, true);
                status(a, "线路换到" + label() + "了");
            }
            return true;
        }
        failCount++;
        backoffMs = backoffFor(failCount);
        nextTryAt = System.currentTimeMillis() + backoffMs;
        if (a != null) conn(a, 0, false);
        return false;
    }

    static boolean reachable(String base, int ms) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(base + "/recent?n=1").openConnection();
            c.setConnectTimeout(ms);
            c.setReadTimeout(ms);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            boolean ok = c.getResponseCode() == 200;
            c.disconnect();
            return ok;
        } catch (Exception e) {
            return false;
        }
    }

    static void switchBase() {
        if (!AUTO_SWITCH) return;
        String other = LAN.equals(BASE) ? WAN : LAN;
        if (reachable(other, 2500)) BASE = other;
    }

    static String imgKey(String url) {
        String key = url;
        int cut = key.indexOf('/', 8);
        if (cut > 0) key = key.substring(cut);
        return "i" + Math.abs(key.hashCode());
    }

    static File imgCache(MainActivity a, String url) {
        File dir = new File(a.getCacheDir(), "img");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, imgKey(url));
    }

    static boolean isLan() {
        return LAN.equals(BASE);
    }

    static String readAll(HttpURLConnection c) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    static void conn(MainActivity a, long ms, boolean ok) {
        if (ok) {
            markOk();
        } else if (System.currentTimeMillis() - lastOkAt < 8000) {
            // 8 秒内刚有请求成功过：这一次失败说明不了线路断了，别把状态条打成失败
            return;
        }
        Message m = Message.obtain();
        m.what = MainActivity.MSG_CONN;
        m.arg1 = (int) Math.min(ms, 60000);
        m.arg2 = ok ? 1 : 0;
        a.ui.sendMessage(m);
    }

    static void err(MainActivity a, String text) {
        Message m = Message.obtain();
        m.what = MainActivity.MSG_ERR;
        m.obj = text;
        a.ui.sendMessage(m);
    }

    static void status(MainActivity a, String text) {
        Message m = Message.obtain();
        m.what = MainActivity.MSG_STATUS;
        m.obj = text;
        a.ui.sendMessage(m);
    }
}
