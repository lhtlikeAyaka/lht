package com.lht.fishchat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.OpenableColumns;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends Activity implements View.OnClickListener, Handler.Callback {
    static final String BASE = "https://napcat.994528.xyz";
    static final int MSG_BATCH = 1;
    static final int MSG_STATUS = 2;
    static final int MSG_POLL_NOW = 3;
    static final int MSG_BITMAP = 4;
    static final int MSG_CONN = 5;
    static final int MSG_SENT = 6;
    static final int MSG_BOOT = 7;
    static final int MSG_ERR = 8;
    static final int MSG_CHECK = 9;
    static final int MSG_SEND_FAIL = 10;
    static final int MSG_UP = 11;
    static final int MSG_UP_DONE = 12;
    static final int MSG_UP_FAIL = 13;
    static final int MSG_STATE = 14;
    static final int MSG_GEN = 15;
    static final int MSG_MOOD = 16;
    static final int MSG_BAL = 17;
    static final int REQ_PICK = 77;

    LinearLayout chat;
    ScrollView scroll;
    EditText input;
    TextView balTv;
    android.widget.FrameLayout connBox;
    View connDot;
    Handler ui;
    long lastId = 0;
    android.content.SharedPreferences prefs;
    String pickKind = "file";
    boolean connOk = false;
    long connMs = 0;
    TextView typingView;
    final java.util.HashMap<Integer, TextView> sentSt = new java.util.HashMap<Integer, TextView>();
    // hist：服务端确认过的消息，严格按 id 升序，是屏幕内容的唯一来源
    // pend：还没拿到服务端 id 的（临时负数 id），画在最下面
    final ArrayList<String> hist = new ArrayList<String>();
    final ArrayList<String> pend = new ArrayList<String>();
    // 在这台设备上「删掉」的消息 id（只本地隐藏，服务端不动），持久化在 prefs
    final java.util.LinkedHashSet<Integer> hid = new java.util.LinkedHashSet<Integer>();
    int drawnCount = 0;       // hist 里已经画到屏幕上的条数（永远是从头开始的一段）
    int putIdx = 0;           // putMsg 上一次插入/命中的位置
    boolean needFull = false; // 下次有数据时整屏重画（gen 变了）
    TextView moodTv;
    LinearLayout moodPanel;
    android.widget.PopupWindow msgPw;
    boolean moodOpen = false;
    double moodVal = -1;
    org.json.JSONObject moodDims;
    String moodReason = "";
    long moodAt = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.main);
        ui = new Handler(this);
        chat = (LinearLayout) findViewById(R.id.chat);
        scroll = (ScrollView) findViewById(R.id.scroll);
        input = (EditText) findViewById(R.id.input);
        balTv = (TextView) findViewById(R.id.bal);
        connBox = (android.widget.FrameLayout) findViewById(R.id.conn);
        connDot = findViewById(R.id.dot);
        setDot(0xFF4B5563);
        typingView = (TextView) findViewById(R.id.typing);
        prefs = getSharedPreferences("fishchat", MODE_PRIVATE);
        Net.ctx = getApplicationContext();
        Net.BASE = Net.baseOf(Net.line());
        connBox.setOnClickListener(this);
        moodTv = (TextView) findViewById(R.id.mood);
        moodTv.setOnClickListener(this);
        moodTv.setBackground(chip());
        moodPanel = (LinearLayout) findViewById(R.id.moodPanel);
        moodOpen = prefs.getBoolean("moodOpen", false);
        Button send = (Button) findViewById(R.id.send);
        Button plus = (Button) findViewById(R.id.plus);
        send.setOnClickListener(this);
        plus.setOnClickListener(this);
        loadCache();
        ui.postDelayed(new MoodTick(this), 200);
        ui.postDelayed(new BalTick(this), 300);
        new Thread(new Prober(this)).start();
    }

    @Override
    protected void onStart() {
        super.onStart();
        startKeep(Net.BASE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Net.pollMs = 3000;
        startKeep(Net.BASE);
        if (hist.size() == 0) new Thread(new Loader(this)).start();
        else new Thread(new Poller(this, lastId)).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        startKeep(Net.BASE);
    }

    void startKeep(String base) {
        Intent it = new Intent(this, ForegroundKeep.class);
        it.putExtra("base", base);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(it);
            else startService(it);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.conn) {
            switchNet();
            return;
        }
        if (v.getId() == R.id.mood) {
            setMoodOpen(!moodOpen);
            return;
        }
        if (v.getId() == R.id.send) {
            String t = input.getText().toString().trim();
            if (t.length() == 0) return;
            input.setText("");
            long now = System.currentTimeMillis() / 1000;
            int tmp = -((int) (System.currentTimeMillis() % 1000000)) - 1;
            TextView st = addText2("老大", t, now, tmp, "sending", 0);
            remember("老大", "text", t, "", "", now, tmp, "sending");
            String cid = System.currentTimeMillis() + "-" + (int) (Math.random() * 100000);
            String body = "text=" + URLEncoder.encode(t) + "&cid=" + cid;
            new Thread(new Poster(this, body, t, st, tmp)).start();
        } else if (v.getId() == R.id.plus) {
            showPlusMenu(v);
        }
    }

    void switchNet() {
        String cur = Net.line();
        String nxt = Net.next(cur);
        prefs.edit().putString("net", nxt).apply();
        Net.BASE = Net.baseOf(nxt);
        Net.gen++;
        connOk = false;
        setConnBusy();
        addStatus("线路切到" + Net.label(nxt) + "，重连中…");
        new Thread(new Prober(this)).start();
    }

    void openPicker(String kind) {
        pickKind = kind;
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType("image".equals(kind) ? "image/*" : ("video".equals(kind) ? "video/*" : "*/*"));
        startActivityForResult(Intent.createChooser(it, "选一个"), REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = guessName(uri);
        TextView up = addUpBubble("发送中 0%");
        new Thread(new Uploader(this, uri, pickKind, name, up)).start();
    }

    String guessName(Uri uri) {
        String n = null;
        try {
            ContentResolver cr = getContentResolver();
            Cursor c = cr.query(uri, null, null, null, null);
            if (c != null) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (c.moveToFirst() && i >= 0) n = c.getString(i);
                c.close();
            }
        } catch (Exception ignored) {
        }
        if (n == null || n.length() == 0) n = "file_" + System.currentTimeMillis();
        return n;
    }

    // 全 App 唯一的时间转换：服务端 ts 是秒，这里统一成毫秒再显示
    String clock(long ts) {
        long ms = ts;
        if (ms <= 0) ms = System.currentTimeMillis();
        else if (ms < 100000000000L) ms = ms * 1000L;
        java.util.Calendar a = java.util.Calendar.getInstance();
        a.setTimeInMillis(ms);
        java.util.Calendar b = java.util.Calendar.getInstance();
        boolean today = a.get(java.util.Calendar.YEAR) == b.get(java.util.Calendar.YEAR)
                && a.get(java.util.Calendar.DAY_OF_YEAR) == b.get(java.util.Calendar.DAY_OF_YEAR);
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat(today ? "HH:mm" : "MM-dd HH:mm");
        return f.format(new java.util.Date(ms));
    }

    // 北京时间 00:30–08:30 是谷时（错峰折扣）
    boolean valley(long ts) {
        long ms = ts;
        if (ms <= 0) return false;
        if (ms < 100000000000L) ms = ms * 1000L;
        long min = ((ms / 60000L) + 8 * 60L) % 1440L;
        return min >= 30L && min < 510L;
    }

    android.widget.TextView stamp(long ts, boolean mine, double cost) {
        android.widget.TextView t = new android.widget.TextView(this);
        String s = clock(ts);
        if (!mine && cost > 0) {
            s = s + "  ¥" + String.format(java.util.Locale.US, "%.2f", cost);
            if (valley(ts)) {
                android.text.SpannableString sp = new android.text.SpannableString(s + "谷");
                sp.setSpan(new android.text.style.RelativeSizeSpan(0.8f), sp.length() - 1, sp.length(),
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                t.setText(sp);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
                t.setTextColor(0xFF9AA4B2);
                t.setPadding(0, dp(3), 0, 0);
                t.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
                return t;
            }
        }
        t.setText(s);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
        t.setTextColor(0xFF9AA4B2);
        t.setPadding(0, dp(3), 0, 0);
        t.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
        return t;
    }

    int px(int id) {
        return getResources().getDimensionPixelSize(id);
    }

    // 气泡最大宽：屏宽 - 96dp（小屏才放得下大字号），最低 120dp
    int bubbleMax() {
        int w = getResources().getDisplayMetrics().widthPixels;
        return Math.max(dp(120), w - dp(96));
    }

    android.graphics.drawable.Drawable bubbleMine() {
        return new BubbleBg(0xFFE4F6F0, 0, 0xFF34B79A, dp(14), dp(2));
    }

    android.graphics.drawable.Drawable bubbleOther() {
        return new BubbleBg(0xFFFFFFFF, 0xFFE7EAEE, 0, dp(14), 0);
    }

    android.graphics.drawable.Drawable chip() {
        return new BubbleBg(0xFFFFFFFF, 0xFFE7EAEE, 0, dp(11), 0);
    }

    android.graphics.drawable.Drawable itemBg() {
        android.graphics.drawable.StateListDrawable sl = new android.graphics.drawable.StateListDrawable();
        android.graphics.drawable.GradientDrawable pressed = new android.graphics.drawable.GradientDrawable();
        pressed.setColor(0xFFEDF1F4);
        pressed.setCornerRadius(dp(10));
        android.graphics.drawable.GradientDrawable normal = new android.graphics.drawable.GradientDrawable();
        normal.setColor(0x00000000);
        normal.setCornerRadius(dp(10));
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    // 心情抽屉的毛玻璃底：抓抽屉背后那一块界面
    void glassDrawer(int h) {
        if (moodPanel == null) return;
        View par = (View) moodPanel.getParent();
        if (par == null) return;
        View root = getWindow().getDecorView().getRootView();
        int[] pp = new int[2];
        int[] wl = new int[2];
        par.getLocationOnScreen(pp);
        root.getLocationOnScreen(wl);
        int gw = par.getWidth() > 0 ? par.getWidth() : getResources().getDisplayMetrics().widthPixels;
        android.graphics.drawable.Drawable bg = Glass.make(this, root, pp[0] - wl[0], pp[1] - wl[1], gw, h, 14);
        if (bg != null) moodPanel.setBackground(bg);
    }

    int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    LinearLayout row(boolean mine) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
        r.setPadding(dp(4), dp(3), dp(4), dp(3));
        return r;
    }

    android.graphics.drawable.GradientDrawable bubble(int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(color);
        return g;
    }

    void addText(String who, String text, long ts) {
        addText2(who, text, ts, -1, "", 0);
    }

    String statusText(int id, String state) {
        if ("sending".equals(state)) return "发送中…";
        if (id <= 0) return "还没送到";
        if ("read".equals(state)) return "已读";
        return "已送达";
    }

    TextView addText2(String who, String text, long ts, int id, String state, double cost) {
        boolean mine = "老大".equals(who);
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_chat));
        tv.setTextColor(mine ? 0xFF17332C : 0xFF1B2028);
        tv.setBackground(mine ? bubbleMine() : bubbleOther());
        tv.setPadding(px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v),
                px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v));
        Linkify.addLinks(tv, Linkify.WEB_URLS);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        tv.setLinkTextColor(0xFF34B79A);
        tv.setLinksClickable(true);
        tv.setMaxWidth(bubbleMax());
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
        col.addView(tv);
        col.addView(stamp(ts, mine, cost));
        TextView st = null;
        if (mine) {
            st = new TextView(this);
            st.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
            st.setTextColor(0xFF9AA4B2);
            st.setGravity(android.view.Gravity.RIGHT);
            st.setPadding(0, dp(1), 0, 0);
            st.setText(statusText(id, state));
            col.addView(st);
            if (id != 0) sentSt.put(Integer.valueOf(id), st);
        }
        LinearLayout r = row(mine);
        // 记下这条气泡的 id（负数=还在发），重建时靠它保住没确认的那条
        r.setTag(Integer.valueOf(id));
        r.addView(col, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        // 长按挂在气泡根容器上，不碰 TextView 的 LinkMovementMethod
        MsgLongTap lt = new MsgLongTap(this, r, id, text);
        r.setOnLongClickListener(lt);
        // TextView 带 LinkMovementMethod 时自己会吃掉按下事件，得单独挂一份
        tv.setOnLongClickListener(lt);
        chat.addView(r);
        scrollDown();
        return st;
    }

    TextView addUpBubble(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_chat));
        tv.setTextColor(0xFF17332C);
        tv.setBackground(bubbleMine());
        tv.setPadding(px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v),
                px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(android.view.Gravity.RIGHT);
        col.addView(tv);
        col.addView(stamp(System.currentTimeMillis() / 1000, true, 0));
        LinearLayout r = row(true);
        r.addView(col);
        tv.setTag(r);
        chat.addView(r);
        scrollDown();
        return tv;
    }

    void addFailRow(String text) {
        TextView tv = new TextView(this);
        tv.setText("刚才那条没送到 · 点这里重发");
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
        tv.setTextColor(0xFFD06A6A);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setBackground(bubble(0x1FD06A6A));
        tv.setPadding(dp(10), dp(6), dp(10), dp(6));
        tv.setClickable(true);
        tv.setOnClickListener(new ResendTap(this, tv, text));
        LinearLayout r = row(false);
        r.addView(tv);
        chat.addView(r);
        scrollDown();
    }

    void addStatus(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
        tv.setTextColor(0xFF9AA4B2);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setPadding(dp(4), dp(3), dp(4), dp(3));
        chat.addView(tv);
        scrollDown();
    }

    void addImage(final String who, final String url, long ts, final int mid, double cost) {
        boolean mine = "老大".equals(who);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(mine ? bubbleMine() : bubbleOther());
        box.setPadding(dp(4), dp(4), dp(4), dp(4));
        ImageView iv = new ImageView(this);
        iv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, px(R.dimen.img_h)));
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setOnTouchListener(new TapZoom(this, mid, url));
        box.addView(iv);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
        col.addView(box, new LinearLayout.LayoutParams(
                bubbleMax(), LinearLayout.LayoutParams.WRAP_CONTENT));
        col.addView(stamp(ts, mine, cost));
        LinearLayout r = row(mine);
        r.addView(col, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        r.setTag(Integer.valueOf(mid));
        chat.addView(r);
        scrollDown();
        new Thread(new ImageLoader(this, iv, url)).start();
    }

    void addLink(String who, String kind, String name, String url, long ts, int mid, double cost) {
        boolean mine = "老大".equals(who);
        TextView tv = new TextView(this);
        String label = "video".equals(kind) ? "🎬 " : "📎 ";
        tv.setText(label + name + "\n" + url);
        tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_chat));
        tv.setTextColor(mine ? 0xFF17332C : 0xFF1B2028);
        tv.setBackground(mine ? bubbleMine() : bubbleOther());
        tv.setPadding(px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v),
                px(R.dimen.pad_bubble_h), px(R.dimen.pad_bubble_v));
        Linkify.addLinks(tv, Linkify.WEB_URLS);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        tv.setLinkTextColor(0xFF34B79A);
        tv.setMaxWidth(bubbleMax());
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(mine ? android.view.Gravity.RIGHT : android.view.Gravity.LEFT);
        col.addView(tv);
        col.addView(stamp(ts, mine, cost));
        LinearLayout r = row(mine);
        r.addView(col, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        r.setTag(Integer.valueOf(mid));
        MsgLongTap lt = new MsgLongTap(this, r, mid, url);
        r.setOnLongClickListener(lt);
        tv.setOnLongClickListener(lt);
        chat.addView(r);
        scrollDown();
    }

    void setDot(int color) {
        if (connDot == null) return;
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        connDot.setBackground(g);
    }

    void setConnBusy() {
        setDot(0xFFD9A227);
    }

    void setConn(boolean ok, long ms) {
        if (connDot == null) return;
        connOk = ok;
        if (ok) {
            if (ms > 0) connMs = ms;
            String ln = Net.line();
            if ("wan".equals(ln) || "frp".equals(ln)) setDot(0xFF7C93AA);
            else setDot(0xFF34B79A);
        } else {
            setDot(0xFFD06A6A);
        }
    }

    void applyBal(String s) {
        try {
            if (s == null || balTv == null) return;
            JSONObject o = new JSONObject(s);
            if (o.isNull("cny")) return;
            double v = o.optDouble("cny", -1);
            if (v < 0) return;
            balTv.setText("¥" + String.format(java.util.Locale.US, "%.2f", v));
        } catch (Exception ignored) {
        }
    }

    void scrollDown() {
        scroll.post(new ScrollTo(this));
    }

    @Override
    public boolean handleMessage(Message m) {
        if (m.what == MSG_STATUS) {
            addStatus((String) m.obj);
        } else if (m.what == MSG_BATCH) {
            renderBatch((String) m.obj);
        } else if (m.what == MSG_POLL_NOW) {
            new Thread(new Poller(this, lastId)).start();
        } else if (m.what == MSG_BOOT) {
            applyGen(m.arg1);
            // 启动时以服务端 /recent 为准合并一次（本地缓存只是离线兜底，不参与排序）
            new Thread(new Loader(this)).start();
        } else if (m.what == MSG_GEN) {
            if (applyGen(m.arg1)) new Thread(new Loader(this)).start();
        } else if (m.what == MSG_SENT) {
            int real = m.arg1;
            int tmp = m.arg2;
            TextView old = m.obj instanceof TextView ? (TextView) m.obj : null;
            String srv = null;
            if (m.obj instanceof Object[]) {
                Object[] p = (Object[]) m.obj;
                if (p.length > 0 && p[0] instanceof TextView) old = (TextView) p[0];
                if (p.length > 1 && p[1] instanceof String) srv = (String) p[1];
            }
            if (real > 0 && srv != null) {
                // 本地那条待确认的换成服务端记录：id、ts、state 一律以服务端为准
                for (int i = pend.size() - 1; i >= 0; i--) {
                    if (idOf(pend.get(i)) == tmp) pend.remove(i);
                }
                removeRowByTag(tmp);
                sentSt.remove(Integer.valueOf(tmp));
                putMsg(srv);
                if (putIdx < drawnCount || pend.size() > 0) {
                    renderAll();
                } else {
                    for (int i = drawnCount; i < hist.size(); i++) drawEntry(hist.get(i));
                }
                saveCache();
            } else if (old != null) {
                old.setText("已送达");
                old.setTextColor(0xFF9BB4C9);
                if (real > 0) {
                    sentSt.remove(Integer.valueOf(tmp));
                    sentSt.put(Integer.valueOf(real), old);
                }
            }
        } else if (m.what == MSG_MOOD) {
            applyMood((String) m.obj);
        } else if (m.what == MSG_BAL) {
            applyBal((String) m.obj);
        } else if (m.what == MSG_STATE) {
            Object[] p = (Object[]) m.obj;
            boolean typing = ((Boolean) p[0]).booleanValue();
            if (typingView != null) typingView.setVisibility(typing ? View.VISIBLE : View.GONE);
            java.util.List<?> ids = (java.util.List<?>) p[1];
            for (int i = 0; i < ids.size(); i++) {
                Object v = ids.get(i);
                if (v instanceof Integer) {
                    TextView st = sentSt.get(v);
                    if (st != null) st.setText("已读");
                    int rid = ((Integer) v).intValue();
                    for (int k = 0; k < hist.size(); k++) {
                        try {
                            JSONObject o = new JSONObject(hist.get(k));
                            if (o.optInt("id", 0) == rid && !"read".equals(o.optString("state", ""))) {
                                o.put("state", "read");
                                hist.set(k, o.toString());
                            }
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        } else if (m.what == MSG_ERR) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("传不上去")
                    .setMessage(String.valueOf(m.obj))
                    .setPositiveButton("知道了", null)
                    .show();
        } else if (m.what == MSG_CONN) {
            setConn(m.arg2 == 1, m.arg1);
        } else if (m.what == MSG_CHECK) {
            if (!connOk) Net.conn(this, -1, false);
        } else if (m.what == MSG_UP) {
            Object[] p = (Object[]) m.obj;
            ((TextView) p[0]).setText("发送中 " + ((Integer) p[1]).intValue() + "%");
        } else if (m.what == MSG_UP_DONE) {
            Object[] p = (Object[]) m.obj;
            TextView tv = (TextView) p[0];
            Object tag = tv.getTag();
            if (tag instanceof View) chat.removeView((View) tag);
            renderBatch("[" + p[1] + "]");
        } else if (m.what == MSG_UP_FAIL) {
            Object[] p = (Object[]) m.obj;
            TextView tv = (TextView) p[0];
            tv.setText("没发出去 · 点这里重试");
            tv.setTextColor(0xFFD06A6A);
            tv.setBackground(bubble(0xFFFDEEEE));
            tv.setClickable(true);
            tv.setOnClickListener(new RetryUpload(this, (Uri) p[1], (String) p[2], (String) p[3]));
        } else if (m.what == MSG_SEND_FAIL) {
            Object[] p = (Object[]) m.obj;
            TextView bubble = (TextView) p[0];
            String t = String.valueOf(p[1]);
            int tmp = p.length > 2 && p[2] instanceof Integer ? ((Integer) p[2]).intValue() : 0;
            if (tmp != 0) {
                for (int i = 0; i < pend.size(); i++) {
                    try {
                        JSONObject o = new JSONObject(pend.get(i));
                        if (o.optInt("id", 0) == tmp) {
                            o.put("state", "fail");
                            pend.set(i, o.toString());
                        }
                    } catch (Exception ignored) {
                    }
                }
                saveCache();
            }
            if (bubble != null) {
                bubble.setText("没送到 · 点这里重发");
                bubble.setTextColor(0xFFD06A6A);
                bubble.setBackground(bubble(0xFFFDEEEE));
                bubble.setClickable(true);
                bubble.setOnClickListener(new ResendTap(this, bubble, t));
            }
            if (input.getText().toString().trim().length() == 0) input.setText(t);
        } else if (m.what == MSG_BITMAP) {
            Object[] p = (Object[]) m.obj;
            ImageView iv = (ImageView) p[0];
            Bitmap bm = (Bitmap) p[1];
            if (bm != null) {
                iv.setImageBitmap(bm);
            } else {
                addStatus("图片没加载出来，点图片重试一次");
                iv.setOnClickListener(new RetryTap(this, iv, (String) p[2]));
            }
        }
        return true;
    }

    static int idOf(String s) {
        try {
            return new JSONObject(s).optInt("id", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    void removeRowByTag(int id) {
        if (chat == null) return;
        for (int i = chat.getChildCount() - 1; i >= 0; i--) {
            View v = chat.getChildAt(i);
            Object tag = v.getTag();
            if (tag instanceof Integer && ((Integer) tag).intValue() == id) chat.removeViewAt(i);
        }
    }

    // 插进 hist：按 id 升序、同一个 id 只留一条。返回 0=没变 1=新插入 2=内容变了 3=顺手清掉一条待确认
    int putMsg(String json) {
        int id = idOf(json);
        if (id <= 0) return 0;
        int idx = -1;
        for (int i = 0; i < hist.size(); i++) {
            if (idOf(hist.get(i)) == id) {
                idx = i;
                break;
            }
        }
        int kind = 0;
        if (idx >= 0) {
            if (!hist.get(idx).equals(json)) {
                hist.set(idx, json);
                kind = 2;
            }
        } else {
            idx = hist.size();
            for (int i = 0; i < hist.size(); i++) {
                if (idOf(hist.get(i)) > id) {
                    idx = i;
                    break;
                }
            }
            hist.add(idx, json);
            kind = 1;
        }
        putIdx = idx;
        String who = "";
        String text = "";
        try {
            JSONObject o = new JSONObject(json);
            who = o.optString("who", "");
            text = o.optString("text", "");
        } catch (Exception ignored) {
        }
        // 同一条消息之前留在待确认里的副本去掉，免得重影
        for (int i = pend.size() - 1; i >= 0; i--) {
            try {
                JSONObject p = new JSONObject(pend.get(i));
                if (who.equals(p.optString("who", "")) && text.equals(p.optString("text", ""))) {
                    removeRowByTag(p.optInt("id", 0));
                    pend.remove(i);
                    kind = 3;
                }
            } catch (Exception ignored) {
            }
        }
        return kind;
    }

    void drawEntry(String json) {
        try {
            drawOne(new JSONObject(json));
        } catch (Exception ignored) {
        }
    }

    void drawOne(JSONObject o) {
        int id = o.optInt("id", 0);
        if (id > 0 && hid.contains(Integer.valueOf(id))) {
            // 本机删掉的：不画，但算作已经消费过，免得后面的追加逻辑错位
            drawnCount++;
            if (id > lastId) lastId = id;
            return;
        }
        String who = o.optString("who", "?");
        String kind = o.optString("kind", "text");
        String text = o.optString("text", "");
        String url = o.optString("url", "");
        String name = o.optString("name", "");
        long ts = o.optLong("ts", 0);
        if (url.length() > 0 && !url.startsWith("http")) url = Net.BASE + url;
        if ("image".equals(kind)) {
            addImage(who, url, ts, id, o.optDouble("cost", 0));
        } else if ("video".equals(kind) || "file".equals(kind)) {
            addLink(who, kind, name.length() > 0 ? name : kind, url, ts, id, o.optDouble("cost", 0));
        } else {
            addText2(who, text, ts, id, o.optString("state", ""), o.optDouble("cost", 0));
        }
        if (id > 0) {
            drawnCount++;
            if (id > lastId) lastId = id;
        }
    }

    // 整屏按 hist（服务端 id 升序）+ pend（还没确认的）重画
    void renderAll() {
        if (chat == null) return;
        chat.removeAllViews();
        sentSt.clear();
        drawnCount = 0;
        lastId = 0;
        for (int i = 0; i < hist.size(); i++) drawEntry(hist.get(i));
        for (int i = 0; i < pend.size(); i++) drawEntry(pend.get(i));
        scrollDown();
    }

    void renderBatch(String json) {
        try {
            org.json.JSONArray arr = new org.json.JSONArray(json);
            int firstNew = hist.size();
            boolean changed = false;
            boolean full = needFull;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (o.optInt("id", 0) <= 0) continue;
                int k = putMsg(o.toString());
                if (k == 0) continue;
                changed = true;
                if (putIdx < drawnCount) full = true;
                if (putIdx < firstNew) firstNew = putIdx;
            }
            if (!changed) {
                if (full) {
                    // 服务端真的清空过、/recent 也确实空了：这才清屏
                    needFull = false;
                    renderAll();
                }
                saveCache();
                return;
            }
            needFull = false;
            if (full || pend.size() > 0) {
                renderAll();
            } else {
                for (int i = firstNew; i < hist.size(); i++) drawEntry(hist.get(i));
            }
            saveCache();
        } catch (Exception e) {
            addStatus("解析出错：" + e.getMessage());
        }
    }

    void loadHid() {
        hid.clear();
        String s = prefs.getString("hid", "");
        if (s.length() == 0) return;
        String[] parts = s.split(",");
        for (int i = 0; i < parts.length; i++) {
            try {
                int v = Integer.parseInt(parts[i].trim());
                if (v > 0) hid.add(Integer.valueOf(v));
            } catch (Exception ignored) {
            }
        }
    }

    void saveHid() {
        // 最多留最近 2000 个，超了就丢最老的
        while (hid.size() > 2000) {
            java.util.Iterator<Integer> it = hid.iterator();
            if (!it.hasNext()) break;
            it.next();
            it.remove();
        }
        StringBuilder sb = new StringBuilder();
        java.util.Iterator<Integer> it = hid.iterator();
        while (it.hasNext()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(it.next().intValue());
        }
        prefs.edit().putString("hid", sb.toString()).apply();
    }

    void hideMsg(int id) {
        if (id > 0) {
            hid.add(Integer.valueOf(id));
            saveHid();
        } else {
            for (int i = pend.size() - 1; i >= 0; i--) {
                if (idOf(pend.get(i)) == id) pend.remove(i);
            }
            saveCache();
        }
        renderAll();
        Toast.makeText(this, "已在这台设备上删除", Toast.LENGTH_SHORT).show();
    }

    // 心情：每 30 秒拉一次 /mood，失败就保留上次的值
    void applyMood(String s) {
        try {
            if (s == null) return;
            JSONObject o = new JSONObject(s);
            if (o.isNull("mood")) return;
            double v = o.optDouble("mood", -1);
            if (v < 0) return;
            moodVal = v;
            moodDims = o.optJSONObject("dims");
            moodReason = o.optString("reason", "");
            moodAt = o.optLong("updatedAt", 0);
            if (moodTv != null) {
                String top = topDim();
                moodTv.setText(top.length() == 0 ? "心情" : "心情 · " + top);
                moodTv.setVisibility(View.VISIBLE);
            }
            if (moodOpen) {
                if (moodPanel.getVisibility() == View.VISIBLE) fillMoodPanel();
                else setMoodOpen(true);
            }
        } catch (Exception ignored) {
        }
    }

    String dimName(String k) {
        if ("happy".equals(k)) return "开心";
        if ("calm".equals(k)) return "平静";
        if ("sweet".equals(k)) return "甜";
        if ("heartache".equals(k)) return "心疼";
        if ("worry".equals(k)) return "担心";
        if ("sad".equals(k)) return "难过";
        if ("jealous".equals(k)) return "吃味";
        return k;
    }

    String topDim() {
        if (moodDims == null) return "";
        String best = null;
        double bv = -1;
        java.util.Iterator<String> it = moodDims.keys();
        while (it.hasNext()) {
            String k = it.next();
            double v = moodDims.optDouble(k, 0);
            if (v > bv) {
                bv = v;
                best = k;
            }
        }
        return best == null ? "" : dimName(best);
    }

    void setMoodOpen(boolean open) {
        if (moodPanel == null) return;
        moodOpen = open;
        prefs.edit().putBoolean("moodOpen", open).apply();
        if (open) {
            if (moodVal < 0) return;
            fillMoodPanel();
            moodPanel.setVisibility(View.VISIBLE);
            int w = moodPanel.getWidth() > 0 ? moodPanel.getWidth()
                    : getResources().getDisplayMetrics().widthPixels;
            moodPanel.measure(android.view.View.MeasureSpec.makeMeasureSpec(w,
                            android.view.View.MeasureSpec.AT_MOST),
                    android.view.View.MeasureSpec.makeMeasureSpec(0,
                            android.view.View.MeasureSpec.UNSPECIFIED));
            int target = moodPanel.getMeasuredHeight();
            if (target <= 0) {
                moodPanel.getLayoutParams().height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
                moodPanel.requestLayout();
                return;
            }
            glassDrawer(target);
            android.animation.ValueAnimator va = android.animation.ValueAnimator.ofInt(0, target);
            va.setDuration(220);
            va.addUpdateListener(new MoodSlide(moodPanel));
            va.addListener(new MoodSlideEnd(moodPanel, true));
            va.start();
        } else {
            int from = moodPanel.getHeight();
            if (from <= 0) {
                moodPanel.setVisibility(View.GONE);
                return;
            }
            android.animation.ValueAnimator va = android.animation.ValueAnimator.ofInt(from, 0);
            va.setDuration(180);
            va.addUpdateListener(new MoodSlide(moodPanel));
            va.addListener(new MoodSlideEnd(moodPanel, false));
            va.start();
        }
    }

    void fillMoodPanel() {
        moodPanel.removeAllViews();
        TextView big = new TextView(this);
        big.setText(String.valueOf(Math.round(moodVal)));
        big.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_big));
        big.setTextColor(0xFF1B2028);
        big.setGravity(android.view.Gravity.CENTER);
        big.setPadding(0, dp(6), 0, dp(2));
        moodPanel.addView(big);
        String[] keys = {"happy", "calm", "sweet", "heartache", "worry", "sad", "jealous"};
        java.util.ArrayList<String> order = new java.util.ArrayList<String>();
        for (int i = 0; i < keys.length; i++) order.add(keys[i]);
        if (moodDims != null) {
            java.util.Iterator<String> it = moodDims.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (!order.contains(k)) order.add(k);
            }
        }
        for (int i = 0; i < order.size(); i++) {
            String k = order.get(i);
            if (moodDims != null && moodDims.has(k)) {
                moodPanel.addView(moodRow(dimName(k), moodDims.optDouble(k, 0)));
            }
        }
        TextView why = new TextView(this);
        why.setText(moodReason);
        why.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
        why.setTextColor(0xFF6B7684);
        why.setPadding(0, dp(8), 0, dp(8));
        moodPanel.addView(why);
    }

    LinearLayout moodRow(String name, double val) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(3), 0, dp(3));
        TextView n = new TextView(this);
        n.setText(name);
        n.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_chat));
        n.setTextColor(0xFF1B2028);
        n.setWidth(dp(48));
        r.addView(n);
        android.widget.ProgressBar pb =
                new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgress((int) Math.round(Math.max(0, Math.min(100, val))));
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF34B79A));
        pb.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFEDF1F4));
        r.addView(pb, new LinearLayout.LayoutParams(0, dp(6), 1f));
        TextView num = new TextView(this);
        num.setText(String.valueOf(Math.round(val)));
        num.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_meta));
        num.setTextColor(0xFF6B7684);
        num.setGravity(android.view.Gravity.RIGHT);
        num.setWidth(dp(34));
        r.addView(num);
        return r;
    }

    // 长按菜单：贴着气泡弹的小浮层，不是全屏对话框
    void dismissMenu() {
        try {
            if (msgPw != null && msgPw.isShowing()) msgPw.dismiss();
        } catch (Exception ignored) {
        }
    }

    void showMsgMenu(View anchor, int id, String text, boolean img, String url) {
        dismissMenu();
        if (anchor == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        if (img) addMenuItem(box, menuItem("打开", new MenuOpen(this, anchor, url)));
        else addMenuItem(box, menuItem("复制", new MenuCopy(this, text)));
        addMenuItem(box, menuItem("删除", new MenuDel(this, id)));
        showPopup(anchor, box, false);
    }

    void showPlusMenu(View anchor) {
        dismissMenu();
        if (anchor == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        addMenuItem(box, menuItem("🖼  图片", new PickTap(this, "image")));
        addMenuItem(box, menuItem("🎬  视频", new PickTap(this, "video")));
        addMenuItem(box, menuItem("📎  文件", new PickTap(this, "file")));
        showPopup(anchor, box, true);
    }

    TextView menuItem(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px(R.dimen.text_menu));
        t.setTextColor(0xFF1B2028);
        t.setGravity(android.view.Gravity.CENTER);
        t.setMinHeight(px(R.dimen.menu_min_h));
        t.setMinWidth(px(R.dimen.menu_min_h));
        t.setPadding(px(R.dimen.menu_pad_h), px(R.dimen.menu_pad_v),
                px(R.dimen.menu_pad_h), px(R.dimen.menu_pad_v));
        t.setBackground(itemBg());
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    void addMenuItem(LinearLayout box, TextView t) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        if (box.getChildCount() > 0) {
            if (box.getOrientation() == LinearLayout.HORIZONTAL) lp.leftMargin = dp(8);
            else lp.topMargin = dp(8);
        }
        box.addView(t, lp);
    }

    // 就地浮层：宽高只包住内容、没有半透明遮罩；跟锚点走，出屏自动往回收
    void showPopup(View anchor, LinearLayout box, boolean preferAbove) {
        android.widget.PopupWindow pw = new android.widget.PopupWindow(box,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        pw.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
        pw.setOutsideTouchable(true);
        pw.setTouchable(true);
        pw.setFocusable(true);
        pw.setElevation(dp(2));
        msgPw = pw;
        box.measure(android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED),
                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED));
        int w = box.getMeasuredWidth();
        int h = box.getMeasuredHeight();
        int[] al = new int[2];
        int[] wl = new int[2];
        anchor.getLocationOnScreen(al);
        getWindow().getDecorView().getLocationOnScreen(wl);
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        int wh = getWindow().getDecorView().getHeight();
        if (wh > dp(40)) sh = wh;
        int ax = al[0] - wl[0];
        int ay = al[1] - wl[1];
        int aw = anchor.getWidth();
        int ah = anchor.getHeight();
        boolean below = ay + ah + dp(2) + h <= sh;
        if (preferAbove && ay - h - dp(2) >= 0) below = false;
        int inset = dp(8);
        int dx = (ax + aw / 2 > sw / 2) ? aw - w : 0;
        int lx = ax + dx;
        if (lx < inset) dx += inset - lx;
        if (lx + w > sw - inset) dx -= (lx + w) - (sw - inset);
        int top = below ? ay + ah + dp(6) : ay - h - dp(6);
        if (top + h > sh - inset) top = sh - inset - h;
        if (top < inset) top = inset;
        int dy = top - (ay + ah);
        View root = getWindow().getDecorView().getRootView();
        android.graphics.drawable.Drawable bg =
                Glass.make(this, root, ax + dx, top, w, h, 14);
        if (bg != null) box.setBackground(bg);
        pw.setWidth(w);
        pw.setHeight(h);
        pw.showAsDropDown(anchor, dx, dy);
    }

    // 离线兜底：读本地缓存的 hist（已按 id 排好）和 pend，整屏画一次
    void loadCache() {
        loadHid();
        hist.clear();
        pend.clear();
        sentSt.clear();
        drawnCount = 0;
        lastId = 0;
        needFull = false;
        String s = prefs.getString("hist", "");
        if (s.length() > 0) {
            String[] lines = s.split("\n");
            for (int i = 0; i < lines.length; i++) {
                if (lines[i].length() == 0) continue;
                // 老版本把没确认的（负数 id）也塞在 hist 里，迁到 pend 去，别丢
                if (idOf(lines[i]) <= 0) pend.add(lines[i]);
                else putMsg(lines[i]);
            }
        }
        String p = prefs.getString("pend", "");
        if (p.length() > 0) {
            String[] lines = p.split("\n");
            for (int i = 0; i < lines.length; i++) {
                if (lines[i].length() > 0) pend.add(lines[i]);
            }
        }
        renderAll();
    }

    boolean applyGen(int sgen) {
        if (sgen < 0) return false;
        int lgen = prefs.getInt("gen", Integer.MIN_VALUE);
        if (sgen == lgen) return false;
        if (lgen == Integer.MIN_VALUE) {
            // 第一次装（或换机）：只记账，不清屏，历史交给 /recent 合并
            prefs.edit().putInt("gen", sgen).apply();
            return false;
        }
        if (sgen < lgen) return false;
        // 服务端 .gen 在 bump 时有「先截断再写」的窗口，/state 会瞬时读成 1；
        // 也可能读到另一条线路上缺 .gen 的老实例。gen 只会变大，变小一律当噪声。
        prefs.edit().putInt("gen", sgen).apply();
        wipeLocal();
        return true;
    }

    void wipeLocal() {
        // 服务端确认清空过：本地确认过的记录作废。屏幕先不动，
        // 等 /recent 回来一次性整屏重画（拉不到也不会把已经显示的聊天记录清没）。
        hist.clear();
        sentSt.clear();
        drawnCount = 0;
        lastId = 0;
        needFull = true;
        if (typingView != null) typingView.setVisibility(View.GONE);
        ImgCache.wipe(this);
        saveCache();
    }

    void saveCache() {
        int from = hist.size() > 500 ? hist.size() - 500 : 0;
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < hist.size(); i++) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(hist.get(i));
        }
        StringBuilder pb = new StringBuilder();
        for (int i = 0; i < pend.size(); i++) {
            if (pb.length() > 0) pb.append('\n');
            pb.append(pend.get(i));
        }
        prefs.edit().putString("hist", sb.toString()).putString("pend", pb.toString()).apply();
    }

    void remember(String who, String kind, String text, String name, String url, long ts, int id, String state) {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("state", state);
            o.put("who", who);
            o.put("kind", kind);
            o.put("text", text);
            o.put("name", name);
            o.put("url", url);
            o.put("ts", ts);
        } catch (Exception ignored) {
        }
        // 还没拿到服务端 id 的，先进 pend；MSG_SENT 时换成服务端记录
        pend.add(o.toString());
        saveCache();
    }
}

class MoodSlide implements android.animation.ValueAnimator.AnimatorUpdateListener {
    final LinearLayout p;
    MoodSlide(LinearLayout p) { this.p = p; }

    public void onAnimationUpdate(android.animation.ValueAnimator a) {
        p.getLayoutParams().height = ((Integer) a.getAnimatedValue()).intValue();
        p.requestLayout();
    }
}

class MoodSlideEnd implements android.animation.Animator.AnimatorListener {
    final LinearLayout p;
    final boolean open;
    MoodSlideEnd(LinearLayout p, boolean open) { this.p = p; this.open = open; }

    public void onAnimationStart(android.animation.Animator a) { }

    public void onAnimationEnd(android.animation.Animator a) {
        if (open) {
            p.getLayoutParams().height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
            p.requestLayout();
        } else {
            p.setVisibility(View.GONE);
        }
    }

    public void onAnimationCancel(android.animation.Animator a) { }

    public void onAnimationRepeat(android.animation.Animator a) { }
}

class BalTick implements Runnable {
    final MainActivity a;
    BalTick(MainActivity a) { this.a = a; }

    public void run() {
        new Thread(new BalPoller(a)).start();
        a.ui.postDelayed(this, 120000);
    }
}

class MoodTick implements Runnable {
    final MainActivity a;
    MoodTick(MainActivity a) { this.a = a; }

    public void run() {
        new Thread(new MoodPoller(a)).start();
        a.ui.postDelayed(this, 30000);
    }
}

class MsgLongTap implements View.OnLongClickListener {
    final MainActivity a;
    final View anchor;
    final int id;
    final String text;

    MsgLongTap(MainActivity a, View anchor, int id, String text) {
        this.a = a;
        this.anchor = anchor;
        this.id = id;
        this.text = text == null ? "" : text;
    }

    public boolean onLongClick(View v) {
        a.showMsgMenu(anchor, id, text, false, "");
        return true;
    }
}

class MenuCopy implements View.OnClickListener {
    final MainActivity a;
    final String text;

    MenuCopy(MainActivity a, String text) {
        this.a = a;
        this.text = text == null ? "" : text;
    }

    public void onClick(View v) {
        a.dismissMenu();
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    a.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("消息", text));
            Toast.makeText(a, "已复制", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(a, "复制不了", Toast.LENGTH_SHORT).show();
        }
    }
}

class MenuOpen implements View.OnClickListener {
    final MainActivity a;
    final View anchor;
    final String url;

    MenuOpen(MainActivity a, View anchor, String url) {
        this.a = a;
        this.anchor = anchor;
        this.url = url == null ? "" : url;
    }

    public void onClick(View v) {
        a.dismissMenu();
        if (anchor instanceof ImageView) ZoomTap.open(a, (ImageView) anchor);
    }
}

class MenuDel implements View.OnClickListener {
    final MainActivity a;
    final int id;

    MenuDel(MainActivity a, int id) {
        this.a = a;
        this.id = id;
    }

    public void onClick(View v) {
        a.dismissMenu();
        new AlertDialog.Builder(a)
                .setTitle("只在这台设备上删除？")
                .setMessage("聊天记录还在服务端，别的设备照样看得到")
                .setPositiveButton("删除", new HideTap(a, id))
                .setNegativeButton("取消", null)
                .show();
    }
}

class PickTap implements View.OnClickListener {
    final MainActivity a;
    final String kind;

    PickTap(MainActivity a, String kind) {
        this.a = a;
        this.kind = kind;
    }

    public void onClick(View v) {
        a.dismissMenu();
        a.openPicker(kind);
    }
}

class HideTap implements DialogInterface.OnClickListener {
    final MainActivity a;
    final int id;

    HideTap(MainActivity a, int id) {
        this.a = a;
        this.id = id;
    }

    public void onClick(DialogInterface d, int i) {
        a.hideMsg(id);
    }
}

class PickListener implements DialogInterface.OnClickListener {
    final MainActivity a;
    PickListener(MainActivity a) { this.a = a; }

    public void onClick(DialogInterface d, int i) {
        a.openPicker(i == 0 ? "image" : (i == 1 ? "video" : "file"));
    }
}

class ScrollTo implements Runnable {
    final MainActivity a;
    ScrollTo(MainActivity a) { this.a = a; }

    public void run() {
        a.scroll.fullScroll(View.FOCUS_DOWN);
    }
}

class ZoomTap implements View.OnClickListener {
    final MainActivity a;
    ZoomTap(MainActivity a) { this.a = a; }

    public void onClick(View v) {
        ZoomTap.open(a, (ImageView) v);
    }

    static void open(MainActivity a, ImageView src) {
        if (src == null || src.getDrawable() == null) return;
        ZoomView big = new ZoomView(a);
        big.setImageDrawable(src.getDrawable());
        big.setBackgroundColor(0xFF05090D);
        android.widget.FrameLayout fl = new android.widget.FrameLayout(a);
        fl.setBackgroundColor(0xFF05090D);
        fl.addView(big, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
        TextView close = new TextView(a);
        close.setText("关闭");
        close.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, a.px(R.dimen.text_menu));
        close.setTextColor(0xFF1B2028);
        close.setBackground(Glass.pseudo(a, 16));
        close.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8));
        android.widget.FrameLayout.LayoutParams clp = new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
        clp.gravity = android.view.Gravity.TOP | android.view.Gravity.RIGHT;
        clp.topMargin = a.dp(10);
        clp.rightMargin = a.dp(10);
        fl.addView(close, clp);
        final android.app.Dialog d = new android.app.Dialog(a,
                android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        d.setContentView(fl);
        d.setCanceledOnTouchOutside(true);
        close.setOnClickListener(new CloseTap(d));
        d.show();
        close.post(new GlassClose(a, d, close));
    }
}

class CloseTap implements View.OnClickListener {
    final android.app.Dialog d;
    CloseTap(android.app.Dialog d) { this.d = d; }
    public void onClick(View v) { d.dismiss(); }
}

class TapDetector extends android.view.GestureDetector.SimpleOnGestureListener {
    final MainActivity a;
    TapDetector(MainActivity a) { this.a = a; }

    public boolean onDoubleTap(android.view.MotionEvent e) {
        return true;
    }

    public boolean onDoubleTapEvent(android.view.MotionEvent e) {
        return true;
    }
}

class TapZoom implements View.OnTouchListener {
    final MainActivity a;
    final int mid;
    final String url;
    long downAt;
    TapZoom(MainActivity a, int mid, String url) {
        this.a = a;
        this.mid = mid;
        this.url = url == null ? "" : url;
    }

    public boolean onTouch(View v, android.view.MotionEvent e) {
        int act = e.getActionMasked();
        if (act == android.view.MotionEvent.ACTION_DOWN) {
            downAt = System.currentTimeMillis();
        } else if (act == android.view.MotionEvent.ACTION_UP) {
            // 按住超过半秒算长按：弹复制/删除菜单，否则照旧点开大图
            if (System.currentTimeMillis() - downAt > 500) {
                a.showMsgMenu(v, mid, "", true, url);
            } else {
                ZoomTap.open(a, (ImageView) v);
                v.performClick();
            }
        }
        return true;
    }
}

class ResendTap implements View.OnClickListener {
    final MainActivity a;
    final TextView tv;
    final String text;
    ResendTap(MainActivity a, TextView tv, String text) { this.a = a; this.tv = tv; this.text = text; }

    public void onClick(View v) {
        tv.setText("正在重发…");
        try {
            String cid = System.currentTimeMillis() + "-" + (int) (Math.random() * 100000);
            String body = "text=" + java.net.URLEncoder.encode(text, "UTF-8") + "&cid=" + cid;
            new Thread(new Poster(a, body, text, null, 0)).start();
        } catch (Exception ignored) {
            tv.setText("重发失败 · 再点一次");
        }
    }
}

class ZoomDbl extends android.view.GestureDetector.SimpleOnGestureListener {
    final ZoomView v;
    ZoomDbl(ZoomView v) { this.v = v; }

    public boolean onDoubleTap(android.view.MotionEvent e) {
        v.toggleDoubleTap(e.getX(), e.getY());
        return true;
    }

    public boolean onDoubleTapEvent(android.view.MotionEvent e) { return true; }
}

class ZoomScale implements android.view.ScaleGestureDetector.OnScaleGestureListener {
    final ZoomView v;
    ZoomScale(ZoomView v) { this.v = v; }

    public boolean onScale(android.view.ScaleGestureDetector d) {
        v.scaleBy(d.getScaleFactor(), d.getFocusX(), d.getFocusY());
        return true;
    }

    public boolean onScaleBegin(android.view.ScaleGestureDetector d) { return true; }

    public void onScaleEnd(android.view.ScaleGestureDetector d) {}
}

class ZoomView extends ImageView {
    final android.graphics.Matrix mat = new android.graphics.Matrix();
    final android.view.ScaleGestureDetector sg;
    final android.view.GestureDetector gd;
    float cur = 1f;
    float base = 1f;

    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    void fit() {
        android.graphics.drawable.Drawable dr = getDrawable();
        if (dr == null || getWidth() == 0 || getHeight() == 0) return;
        float iw = dr.getIntrinsicWidth(), ih = dr.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) return;
        float s = Math.min(getWidth() / iw, getHeight() / ih);
        mat.reset();
        mat.setScale(s, s);
        mat.postTranslate((getWidth() - iw * s) / 2f, (getHeight() - ih * s) / 2f);
        base = s;
        cur = 1f;
        setImageMatrix(mat);
    }

    ZoomView(android.content.Context c) {
        super(c);
        setScaleType(ImageView.ScaleType.MATRIX);
        sg = new android.view.ScaleGestureDetector(c, new ZoomScale(this));
        gd = new android.view.GestureDetector(c, new ZoomDbl(this));
    }

    public boolean onTouchEvent(android.view.MotionEvent e) {
        sg.onTouchEvent(e);
        gd.onTouchEvent(e);
        return true;
    }

    void clamp() {
        if (cur < 1f) { fit(); return; }
        if (cur > 6f) cur = 6f;
        setImageMatrix(mat);
    }

    void scaleBy(float f, float fx, float fy) {
        float next = cur * f;
        if (next < 1f) f = 1f / cur;
        if (next > 6f) f = 6f / cur;
        mat.postScale(f, f, fx, fy);
        cur = cur * f;
        clamp();
    }

    void toggleDoubleTap(float fx, float fy) {
        if (cur > 1.05f) {
            fit();
        } else {
            float f = 2.2f;
            mat.postScale(f, f, getWidth() / 2f, getHeight() / 2f);
            cur = f;
            clamp();
        }
    }
}

class RetryUpload implements View.OnClickListener {
    final MainActivity a;
    final Uri uri;
    final String kind;
    final String name;
    RetryUpload(MainActivity a, Uri uri, String kind, String name) {
        this.a = a; this.uri = uri; this.kind = kind; this.name = name;
    }

    public void onClick(View v) {
        Object tag = v.getTag();
        if (tag instanceof View) a.chat.removeView((View) tag);
        TextView tv = a.addUpBubble("发送中 0%");
        new Thread(new Uploader(a, uri, kind, name, tv)).start();
    }
}

class RetryTap implements View.OnClickListener {
    final MainActivity a;
    final ImageView iv;
    final String url;
    RetryTap(MainActivity a, ImageView iv, String url) { this.a = a; this.iv = iv; this.url = url; }

    public void onClick(View v) {
        iv.setOnClickListener(new ZoomTap(a));
        new Thread(new ImageLoader(a, iv, url)).start();
    }
}

class ImgCache {
    static void wipe(MainActivity a) {
        try {
            File dir = new File(a.getCacheDir(), "img");
            del(dir);
            dir.mkdirs();
        } catch (Exception ignored) {
        }
    }

    static void del(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (int i = 0; i < kids.length; i++) del(kids[i]);
            }
        }
        f.delete();
    }
}

// 圆角气泡/标签底：可带一条左侧强调细边（我方气泡用）
class BubbleBg extends android.graphics.drawable.Drawable {
    final int fill;
    final int border;
    final int accent;
    final int radius;
    final int edge;

    BubbleBg(int fill, int border, int accent, int radius, int edge) {
        this.fill = fill;
        this.border = border;
        this.accent = accent;
        this.radius = radius;
        this.edge = edge;
    }

    public void draw(android.graphics.Canvas c) {
        android.graphics.Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        android.graphics.RectF rf = new android.graphics.RectF(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setStyle(android.graphics.Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(rf, radius, radius, p);
        if (edge > 0) {
            p.setColor(accent);
            android.graphics.RectF bar = new android.graphics.RectF(
                    b.left + radius / 2, b.top + radius, b.left + radius / 2 + edge, b.bottom - radius);
            c.drawRoundRect(bar, edge / 2f, edge / 2f, p);
        }
        if (border != 0) {
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(border);
            android.graphics.RectF sr = new android.graphics.RectF(
                    b.left + 0.5f, b.top + 0.5f, b.right - 0.5f, b.bottom - 0.5f);
            c.drawRoundRect(sr, radius, radius, p);
        }
    }

    public void setAlpha(int a) { }

    public void setColorFilter(android.graphics.ColorFilter cf) { }

    public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
}

// 小面积毛玻璃：RenderScript 真模糊，不行才退化成半透明白
class Glass {
    static boolean rsOk = true;

    static android.graphics.Bitmap snap(MainActivity a, View root, int x, int y, int w, int h) {
        try {
            if (a == null || root == null || w <= 0 || h <= 0) return null;
            int rw = root.getWidth();
            int rh = root.getHeight();
            if (rw <= 0 || rh <= 0) return null;
            android.graphics.Bitmap full = android.graphics.Bitmap.createBitmap(rw, rh,
                    android.graphics.Bitmap.Config.ARGB_8888);
            root.draw(new android.graphics.Canvas(full));
            int sx = Math.max(0, x);
            int sy = Math.max(0, y);
            int ex = Math.min(rw, x + w);
            int ey = Math.min(rh, y + h);
            if (ex - sx <= 0 || ey - sy <= 0) {
                full.recycle();
                return null;
            }
            android.graphics.Bitmap crop = android.graphics.Bitmap.createBitmap(full, sx, sy, ex - sx, ey - sy);
            full.recycle();
            android.graphics.Bitmap small = android.graphics.Bitmap.createScaledBitmap(crop,
                    Math.max(1, crop.getWidth() / 2), Math.max(1, crop.getHeight() / 2), true);
            crop.recycle();
            return small;
        } catch (Throwable t) {
            return null;
        }
    }

    static boolean blur(MainActivity a, android.graphics.Bitmap bmp, float r) {
        if (a == null || bmp == null || !rsOk) return false;
        try {
            android.renderscript.RenderScript rs = android.renderscript.RenderScript.create(a);
            android.renderscript.Allocation in = android.renderscript.Allocation.createFromBitmap(rs, bmp);
            android.renderscript.Allocation out = android.renderscript.Allocation.createTyped(rs, in.getType());
            android.renderscript.ScriptIntrinsicBlur b =
                    android.renderscript.ScriptIntrinsicBlur.create(rs, android.renderscript.Element.U8_4(rs));
            b.setRadius(r);
            b.setInput(in);
            b.forEach(out);
            out.copyTo(bmp);
            in.destroy();
            out.destroy();
            b.destroy();
            rs.destroy();
            return true;
        } catch (Throwable t) {
            rsOk = false;
            return false;
        }
    }

    static android.graphics.drawable.Drawable make(MainActivity a, View root, int x, int y, int w, int h, int radius) {
        if (a == null || w <= 0 || h <= 0) return null;
        int r = Math.max(4, radius);
        android.graphics.Bitmap bmp = snap(a, root, x, y, w, h);
        boolean ok = blur(a, bmp, 22f);
        if (!ok || bmp == null) return pseudo(a, r);
        try {
            android.graphics.Bitmap big = android.graphics.Bitmap.createScaledBitmap(bmp, w, h, true);
            bmp.recycle();
            android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(w, h,
                    android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas c = new android.graphics.Canvas(out);
            android.graphics.Path p = new android.graphics.Path();
            android.graphics.RectF rf = new android.graphics.RectF(0, 0, w, h);
            p.addRoundRect(rf, a.dp(r), a.dp(r), android.graphics.Path.Direction.CW);
            c.save();
            c.clipPath(p);
            c.drawBitmap(big, 0, 0, null);
            c.drawColor(0xCCFFFFFF);
            c.restore();
            android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            pt.setStyle(android.graphics.Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1, a.dp(1)));
            pt.setColor(0x10000000);
            c.drawPath(p, pt);
            big.recycle();
            return new android.graphics.drawable.BitmapDrawable(a.getResources(), out);
        } catch (Throwable t) {
            return pseudo(a, r);
        }
    }

    static android.graphics.drawable.Drawable pseudo(MainActivity a, int radius) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(a.dp(radius));
        g.setColor(0xF2FFFFFF);
        g.setStroke(Math.max(1, a.dp(1)), 0xFFE7EAEE);
        return g;
    }
}

// 大图预览里「关闭」按钮的毛玻璃：等对话框显示后再抓图
class GlassClose implements Runnable {
    final MainActivity a;
    final android.app.Dialog d;
    final TextView close;

    GlassClose(MainActivity a, android.app.Dialog d, TextView close) {
        this.a = a;
        this.d = d;
        this.close = close;
    }

    public void run() {
        try {
            View root = d.getWindow().getDecorView();
            int[] cl = new int[2];
            int[] rl = new int[2];
            close.getLocationOnScreen(cl);
            root.getLocationOnScreen(rl);
            int w = close.getWidth();
            int h = close.getHeight();
            if (w <= 0 || h <= 0) return;
            android.graphics.drawable.Drawable bg =
                    Glass.make(a, root, cl[0] - rl[0], cl[1] - rl[1], w, h, 16);
            if (bg != null) close.setBackground(bg);
        } catch (Throwable t) {
        }
    }
}
