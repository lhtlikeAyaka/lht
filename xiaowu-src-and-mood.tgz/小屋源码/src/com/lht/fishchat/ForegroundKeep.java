package com.lht.fishchat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.net.HttpURLConnection;
import java.net.URL;

public class ForegroundKeep extends Service {
    static final String CH = "fishchat";
    static final int NID = 1001;

    Handler h;
    String base = Net.WAN;
    final KeepBeat beat = new KeepBeat(this);

    public IBinder onBind(Intent i) { return null; }

    public void onCreate() {
        super.onCreate();
        h = new Handler(Looper.getMainLooper());
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel c = new NotificationChannel(CH, "小鱼在线", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
    }

    public int onStartCommand(Intent it, int flags, int startId) {
        if (it != null && it.getStringExtra("base") != null) base = it.getStringExtra("base");
        Notification n;
        if (Build.VERSION.SDK_INT >= 26) {
            n = new Notification.Builder(this, CH)
                    .setContentTitle("小鱼在线")
                    .setContentText("正在保持连接，后台也不会掉线")
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .build();
        } else {
            n = new Notification.Builder(this)
                    .setContentTitle("小鱼在线")
                    .setContentText("正在保持连接，后台也不会掉线")
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .build();
        }
        startForeground(NID, n);
        h.removeCallbacks(beat);
        h.post(beat);
        return START_STICKY;
    }

    public void onDestroy() {
        h.removeCallbacks(beat);
        super.onDestroy();
    }
}

class KeepBeat implements Runnable {
    final ForegroundKeep s;
    KeepBeat(ForegroundKeep s) { this.s = s; }

    public void run() {
        new Thread(new KeepPing(s)).start();
        s.h.postDelayed(this, 3000);
    }
}

class KeepPing implements Runnable {
    final ForegroundKeep s;
    KeepPing(ForegroundKeep s) { this.s = s; }

    public void run() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(Net.BASE + "/recent?n=1").openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            int code = c.getResponseCode();
            if (code == 200) c.getInputStream().close();
            c.disconnect();
            if (code != 200) Net.failover(null);
        } catch (Exception e) {
            Net.failover(null);
        }
    }
}
