package com.lht.fishchat;

import android.widget.TextView;

class Scroller implements Runnable {
    final TextView v;
    Scroller(TextView v) { this.v = v; }

    public void run() {
        if (v.getLayout() != null) {
            int y = v.getLayout().getLineTop(v.getLineCount()) - v.getHeight();
            v.scrollTo(0, y > 0 ? y : 0);
        }
    }
}
