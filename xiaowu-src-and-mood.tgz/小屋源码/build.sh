#!/bin/bash
set -e
AJ=/tmp/android-8.1.0/android.jar
D8=/opt/r8-8.5.35.jar
OUT=build; rm -rf $OUT; mkdir -p $OUT/gen $OUT/obj
aapt package -f -m -J $OUT/gen -M AndroidManifest.xml -S res -A assets -I $AJ -F $OUT/base.apk
javac -nowarn --release 8 -classpath $AJ -d $OUT/obj $(find src $OUT/gen -name "*.java")
java -cp $D8 com.android.tools.r8.D8 --release --min-api 21 --lib $AJ --output $OUT $(find $OUT/obj -name "*.class")
cp $OUT/base.apk $OUT/unsigned.apk
(cd $OUT && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f 4 $OUT/unsigned.apk $OUT/aligned.apk
[ -f debug.keystore ] || keytool -genkeypair -keystore debug.keystore -alias fish -keyalg RSA -keysize 2048 -validity 10000 -storepass fishfish -keypass fishfish -dname "CN=fish" >/dev/null 2>&1
apksigner sign --ks debug.keystore --ks-pass pass:fishfish --key-pass pass:fishfish --out $OUT/fishchat.apk $OUT/aligned.apk
ls -lh $OUT/fishchat.apk
