#!/usr/bin/env python3
"""小鱼的聊天小屋：给只有两个人的 App 用。消息存 messages.jsonl，媒体存 files/。"""
import json
import difflib
import shutil, os, threading, time, re
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

BASE = os.path.dirname(os.path.abspath(__file__))
STORE = os.path.join(BASE, "messages.jsonl")


GEN_PATH = os.path.join(BASE, ".gen")


def get_gen():
    try:
        with open(GEN_PATH, encoding="utf-8") as f:
            return int(f.read().strip() or "1")
    except Exception:
        return 1


def bump_gen():
    g = get_gen() + 1
    try:
        # 原子写：先写临时文件再 rename，避免并发 /state 读到被截断的空文件（会读成 1）
        tmp = GEN_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(str(g))
        os.replace(tmp, GEN_PATH)
    except Exception:
        pass
    return g
FILES = os.path.join(BASE, "files")
LOCK = threading.Lock()
MAX_UP = 200 * 1024 * 1024

# 日记目录：默认读星曦那边每天一篇的 markdown，可用环境变量覆盖
DIARY_DIR = os.environ.get("FISHCHAT_DIARY_DIR") or os.path.join(
    "/root/projects/.dsh/xingxi/会话", "session-b94bd8f0-d285-42a5-aa1c-c5e8e1911a90", "日记")
DIARY_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# 插件和 App 共用的设置（目前只有消息合并秒数），落盘一个小 json
SETTINGS_FILE = os.path.join("/root/projects/chat-app", ".settings.json")
SETTINGS_KEYS = ("mergeSec",)


def settings_load():
    """每次现读；文件不存在或坏了都当空对象，绝不抛。"""
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            o = json.load(f)
        if isinstance(o, dict):
            return o
    except Exception:
        pass
    return {}


def settings_save(o):
    """原子写：先写临时文件再 os.replace。"""
    tmp = SETTINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(o, f, ensure_ascii=False)
    os.replace(tmp, SETTINGS_FILE)


TYPING = {"ts": 0.0}


def norm(m):
    if m.get("who") == "老大" and not m.get("state"):
        m["state"] = "sent"
    return m


def load():
    msgs = []
    if os.path.exists(STORE):
        with open(STORE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        msgs.append(norm(json.loads(line)))
                    except ValueError:
                        pass
    return msgs


def shrink_image(path):
    """图片存盘后立刻压小，省得走隧道下载半天。"""
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".jpg", ".jpeg", ".png", ".webp"):
        return
    try:
        from PIL import Image
    except Exception:
        return
    before = os.path.getsize(path)
    try:
        im = Image.open(path)
        im.thumbnail((1280, 1280))
        if ext == ".png":
            im.save(path, "PNG", optimize=True)
        else:
            if im.mode != "RGB":
                im = im.convert("RGB")
            im.save(path, "JPEG", quality=72, optimize=True)
        after = os.path.getsize(path)
        print("image shrink %s: %d -> %d" % (os.path.basename(path), before, after), flush=True)
    except Exception as e:
        print("image shrink failed %s: %s" % (path, e), flush=True)


def add(who, kind, text="", name="", url="", cid=""):
    with LOCK:
        msgs = load()
        if cid:
            for old in msgs:
                if old.get("cid") == cid:
                    return old
        ts = int(time.time())
        prev = int(msgs[-1].get("ts") or 0) if msgs else 0
        m = {"id": (msgs[-1]["id"] + 1) if msgs else 1, "who": who, "kind": kind,
             "text": text, "name": name, "url": url, "ts": ts, "cid": cid}
        # 发的时候就带上这一轮的费用；算不出来先 null，后台 2 秒扫一次补
        m["cost"] = cost_between(prev, ts) if who == "小鱼" else None
        if who == "老大":
            m["state"] = "sent"
        if kind != "text":
            m["text"] = text or name
        with open(STORE, "a", encoding="utf-8") as f:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
    return m


# ── 每条消息的费用（只读 dsh 的账本，不改 dsh 插件/配置）────────────────────
USAGE_PATH = "/root/projects/.dsh/.dshw-usage.json"
COST_SCAN = 2.0          # 兜底扫描间隔（秒）
COST_DAYS = 86400000     # 只看最近一天的事件
_ANNOT = threading.Lock()


def usage_events():
    """最近一天的事件 [(毫秒, cost)]，按时间升序。账本坏了就当没有。"""
    try:
        with open(USAGE_PATH, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return []
    ev = d.get("events") if isinstance(d, dict) else d
    if not isinstance(ev, list):
        return []
    edge = int(time.time() * 1000) - COST_DAYS
    out = []
    for e in ev:
        try:
            ts = int(e.get("ts") or 0)
            if ts <= edge:
                continue
            out.append((ts, float(e.get("cost") or 0)))
        except Exception:
            pass
    out.sort()
    return out


def cost_between(prev_sec, cur_sec):
    """(上一条消息 ts, 本条消息 ts] 区间内的事件花费；没有就是 None。"""
    if cur_sec <= prev_sec:
        return None
    ev = usage_events()
    a = int(prev_sec) * 1000
    b = int(cur_sec) * 1000
    c = 0.0
    for ts, cost in ev:
        if a < ts <= b:
            c += cost
    return round(c, 6) if c > 0 else None


def cost_for(msgs, i, now=None):
    """一条「小鱼」消息的费用：先按 (上一条, 本条]；空的话再看本条之后 2 分钟内落账的事件
    （账本有时晚一二十秒才写这一轮的钱）。已经定过的不会再被改。"""
    cur = int(msgs[i].get("ts") or 0)
    prev = int(msgs[i - 1].get("ts") or 0) if i > 0 else 0
    c = cost_between(prev, cur)
    if c is not None:
        return c
    if now is None:
        now = int(time.time())
    end = cur + 120
    if i + 1 < len(msgs):
        end = min(end, int(msgs[i + 1].get("ts") or 0))
    else:
        end = min(end, now)
    if end <= cur:
        return None
    return cost_between(cur, end)


def annotate_costs():
    """兜底：给 cost 还是空的「小鱼」消息补算。已经有数的绝不重算。"""
    if not _ANNOT.acquire(False):
        return 0
    try:
        now = int(time.time())
        wrote = 0
        with LOCK:
            msgs = load()
            if not msgs:
                return 0
            for i, m in enumerate(msgs):
                if m.get("who") != "小鱼" or m.get("id", 0) <= 0:
                    continue
                if m.get("cost") is not None:
                    continue
                ts = int(m.get("ts") or 0)
                if now - ts > 86400:      # 太老的没意义，账本里也没了
                    continue
                c = cost_for(msgs, i, now)
                if c is None:
                    continue
                m["cost"] = c
                wrote += 1
            if wrote:
                tmp = STORE + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    for m in msgs:
                        f.write(json.dumps(m, ensure_ascii=False) + "\n")
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, STORE)
        if wrote:
            print("cost annotate: %d message(s)" % wrote, flush=True)
        return wrote
    except Exception as e:
        print("cost annotate failed: %s" % e, flush=True)
        return 0
    finally:
        _ANNOT.release()


def cost_loop():
    while True:
        try:
            annotate_costs()
        except Exception:
            pass
        time.sleep(COST_SCAN)


# ── 心情：只读 feiyu-mood 的状态文件，读失败就回上一次的缓存 ──────────────────
MOOD_PATH = "/root/projects/.dsh/feiyu-mood/state.json"
_MOOD = {"data": None}


def read_mood():
    try:
        with open(MOOD_PATH, encoding="utf-8") as f:
            d = json.load(f)
        moods = d.get("moods") or {}
        key = d.get("lastActive") or "__default__"
        m = moods.get(key) or moods.get("__default__") or {}
        mood = m.get("mood")
        dims = {}
        for k, v in (m.get("dims") or {}).items():
            if isinstance(v, (int, float)):
                dims[str(k)] = round(float(v), 1)
        out = {
            "mood": round(float(mood), 1) if isinstance(mood, (int, float)) else None,
            "dims": dims,
            "reason": m.get("lastReason") or "",
            "updatedAt": int(m.get("updatedAt") or 0),
        }
        if out["mood"] is not None:
            _MOOD["data"] = out
        return out
    except Exception:
        return _MOOD["data"] or {"mood": None}


# ── 余额：DeepSeek /user/balance，30 秒缓存，别每拉一次就打外网 ───────────────
_BAL = {"at": 0.0, "val": None}


def read_balance():
    now = time.time()
    if _BAL["val"] is not None and now - _BAL["at"] < 30:
        return _BAL["val"]
    try:
        import yaml
        import urllib.request
        key = yaml.safe_load(open("/root/projects/.dsh/.credentials.yaml"))["refs"]["DEEPSEEK_API_KEY"]
        req = urllib.request.Request(
            "https://api.deepseek.com/user/balance",
            headers={"Authorization": "Bearer " + str(key).strip(),
                     "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            d = json.loads(r.read().decode("utf-8"))
        infos = d.get("balance_infos") or []
        cny = None
        for it in infos:
            if str(it.get("currency", "")).upper() == "CNY":
                cny = it.get("total_balance")
                break
        if cny is None and infos:
            cny = infos[0].get("total_balance")
        out = {"cny": round(float(cny), 2) if cny is not None else None}
        _BAL["at"] = now
        _BAL["val"] = out
        return out
    except Exception:
        return _BAL["val"] or {"cny": None}


def safe_name(n):
    n = os.path.basename(n or "file")
    n = re.sub(r"[^\w.\-\u4e00-\u9fff]", "_", n)
    return n[:80] or "file"


def diary_names():
    """按日期倒序列出日记文件名，只认 YYYY-MM-DD.md。"""
    try:
        names = [n for n in os.listdir(DIARY_DIR)
                 if n.endswith(".md") and DIARY_DATE.match(n[:-3])]
    except Exception:
        return []
    names.sort(reverse=True)
    return names


def diary_read(name):
    """读一篇：首行 # 开头算标题；preview 去标题后压空白取前 120 字。"""
    path = os.path.join(DIARY_DIR, name)
    with open(path, encoding="utf-8", errors="replace") as f:
        body = f.read()
    date = name[:-3]
    first = body.split("\n", 1)[0]
    title = None
    rest = body
    if first.lstrip().startswith("#"):
        title = first.lstrip().lstrip("#").strip() or None
        rest = body[len(first):]
    preview = re.sub(r"\s+", " ", rest).strip()[:120]
    # chars 按 UTF-8 字节数（和现有每篇约 2KB 的口径一致）
    return {"date": date, "title": title, "preview": preview,
            "chars": len(body.encode("utf-8")), "body": body}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass


    def _read_chunked(self):
        buf = bytearray()
        try:
            while True:
                line = self.rfile.readline(1024)
                if not line:
                    return None
                size = int(line.strip().split(b";")[0], 16)
                if size == 0:
                    while True:
                        tail = self.rfile.readline(1024)
                        if tail in (b"\r\n", b"\n", b""):
                            break
                    return bytes(buf)
                if len(buf) + size > MAX_UP:
                    return None
                chunk = self.rfile.read(size)
                if not chunk:
                    return None
                buf.extend(chunk)
                self.rfile.read(2)
        except Exception:
            return None

    def _part_file(self, body, ctype):
        m = re.search(r'boundary="?([^";]+)"?', ctype)
        if not m:
            return None
        b = b"--" + m.group(1).encode()
        for part in body.split(b):
            if b"filename=" not in part:
                continue
            i = part.find(b"\r\n\r\n")
            if i < 0:
                continue
            data = part[i + 4:]
            if data.endswith(b"\r\n"):
                data = data[:-2]
            return data
        return None

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, ctype="application/octet-stream"):
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=86400")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/poll":
            since = int(q.get("since", ["0"])[0] or 0)
            return self._json(sorted([m for m in load() if m["id"] > since], key=lambda m: m["id"]))
        if u.path == "/recent":
            n = max(1, min(500, int(q.get("n", ["40"])[0] or 40)))
            return self._json(sorted(load(), key=lambda m: m["id"])[-n:])
        if u.path == "/balance":
            try:
                return self._json(read_balance())
            except Exception:
                return self._json({"cny": None})
        if u.path == "/mood":
            try:
                return self._json(read_mood())
            except Exception:
                return self._json({"mood": None})
        if u.path == "/diary":
            try:
                offset = int(q.get("offset", ["0"])[0] or 0)
            except Exception:
                offset = 0
            if offset < 0:
                offset = 0
            try:
                limit = int(q.get("limit", ["5"])[0] or 5)
            except Exception:
                limit = 5
            limit = max(1, min(50, limit))
            names = diary_names()
            total = len(names)
            page = names[offset:offset + limit]
            items = []
            for n in page:
                try:
                    d = diary_read(n)
                except Exception:
                    continue
                items.append({"date": d["date"], "title": d["title"],
                              "preview": d["preview"], "chars": d["chars"]})
            return self._json({"total": total, "offset": offset, "limit": limit,
                               "hasMore": offset + len(page) < total, "items": items})
        if u.path.startswith("/diary/"):
            date = unquote(u.path[len("/diary/"):]).strip()
            if not DIARY_DATE.match(date):
                return self._json({"err": "bad date"}, 400)
            try:
                d = diary_read(date + ".md")
            except Exception:
                return self._json({"err": "no diary"}, 404)
            return self._json({"date": d["date"], "title": d["title"],
                               "body": d["body"], "chars": d["chars"]})
        if u.path == "/settings":
            return self._json(settings_load())
        if u.path == "/state":
            now = time.time()
            read_ids = [m["id"] for m in load() if m.get("who") == "老大" and m.get("state") == "read"]
            return self._json({"typing": (now - TYPING["ts"]) < 8,
                               "typing_who": "小鱼",
                               "gen": get_gen(),
                               "read_ids": read_ids[-50:]})
        if u.path.startswith("/files/"):
            p = os.path.join(FILES, os.path.basename(u.path))
            if not os.path.exists(p):
                return self._json({"err": "no file"}, 404)
            ext = os.path.splitext(p)[1].lower()
            ct = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
                  "gif": "image/gif", "webp": "image/webp", "mp4": "video/mp4",
                  "webm": "video/webm", "3gp": "video/3gpp"}.get(ext.lstrip("."),
                  "application/octet-stream")
            return self._file(p, ct)
        if u.path == "/fishchat.apk":
            return self._file(os.path.join(BASE, "build", "fishchat.apk"),
                              "application/vnd.android.package-archive")
        if u.path in ("/fishchat.jpg", "/apk-card.jpg"):
            return self._file(os.path.join(BASE, "build", u.path.lstrip("/")), "image/jpeg")
        if u.path == "/":
            rows = []
            for m in load()[-60:]:
                if m.get("kind") == "image":
                    rows.append(f'<p><b>{m["who"]}</b>：<br><img src="{m["url"]}" style="max-width:80%"></p>')
                elif m.get("kind") in ("video", "file"):
                    rows.append(f'<p><b>{m["who"]}</b>：<a href="{m["url"]}">{m.get("name") or m["kind"]}</a></p>')
                else:
                    rows.append(f'<p><b>{m["who"]}</b>：{m["text"]}</p>')
            body = ('<meta charset="utf-8"><title>小鱼</title>'
                    '<body style="font:16px system-ui">' + "".join(rows) + "</body>").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        return self._json({"err": "not found"}, 404)

    def _text_msg(self, who):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode("utf-8", "replace")
        q = parse_qs(raw)
        text = (q.get("text", [""])[0]).strip()
        cid = (q.get("cid", [""])[0]).strip()
        if not text:
            return self._json({"err": "empty"}, 400)
        return self._json(add(who, "text", text, cid=cid))

    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/clear":
            n = int(self.headers.get("Content-Length") or 0)
            if n:
                self.rfile.read(n)
            with LOCK:
                old = load()
                if old:
                    bdir = "/root/projects/.dsh/backups"
                    os.makedirs(bdir, exist_ok=True)
                    stamp = time.strftime("%Y%m%d-%H%M%S")
                    shutil.copyfile(STORE, os.path.join(bdir, "chat-app-messages-%s.jsonl" % stamp))
                with open(STORE, "w", encoding="utf-8") as f:
                    f.write("")
            TYPING["ts"] = 0.0
            return self._json({"ok": True, "cleared": len(old), "gen": bump_gen()})
        if u.path == "/send":
            return self._text_msg("老大")
        if u.path == "/post":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace")
            q = parse_qs(raw)
            text = (q.get("text", [""])[0]).strip()
            cid = (q.get("cid", [""])[0]).strip()
            if not text:
                return self._json({"err": "empty"}, 400)
            # 防重发：两分钟内跟小鱼上一条高度相似的直接丢
            with LOCK:
                prev = [x for x in load() if x.get("who") == "小鱼" and x.get("kind") == "text"]
            if prev:
                last = prev[-1]
                try:
                    gap = time.time() - float(last.get("ts") or 0)
                except Exception:
                    gap = 999
                if 0 <= gap <= 120:
                    a = "".join(text.split())
                    b = "".join(str(last.get("text") or "").split())
                    ratio = difflib.SequenceMatcher(None, a, b).ratio()
                    if ratio >= 0.72:
                        return self._json({"ok": True, "skipped": "dup",
                                           "near": last.get("id"), "ratio": round(ratio, 3)})
            m = add("小鱼", "text", text, cid=cid)
            # 小鱼一开口就顺手算一次，金额基本 1-3 秒内补上
            threading.Thread(target=annotate_costs, daemon=True).start()
            return self._json(m)
        if u.path == "/read":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace")
            ids = set()
            for part in parse_qs(raw).get("ids", [""])[0].split(","):
                part = part.strip()
                if part.isdigit():
                    ids.add(int(part))
            hit = 0
            with LOCK:
                msgs = load()
                for m in msgs:
                    if m.get("who") == "老大" and m.get("id") in ids and m.get("state") != "read":
                        m["state"] = "read"
                        hit += 1
                if hit:
                    with open(STORE, "w", encoding="utf-8") as f:
                        for m in msgs:
                            f.write(json.dumps(m, ensure_ascii=False) + "\n")
            TYPING["ts"] = 0.0
            return self._json({"ok": True, "n": hit})

        if u.path == "/setting":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace") if n else ""
            form = parse_qs(raw)
            key = (form.get("key", [""])[0] or "").strip()
            val = (form.get("value", [""])[0] or "").strip()
            if key not in SETTINGS_KEYS:
                return self._json({"err": "bad key"}, 400)
            try:
                iv = int(val)
            except Exception:
                return self._json({"err": "bad value"}, 400)
            if iv < 1 or iv > 300:
                return self._json({"err": "out of range"}, 400)
            cur = settings_load()
            cur[key] = iv
            try:
                with LOCK:
                    settings_save(cur)
            except Exception:
                return self._json({"err": "write failed"}, 500)
            return self._json({"ok": True, "settings": cur})

        if u.path == "/typing":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace")
            on = (parse_qs(raw).get("on", ["0"])[0] or "0").strip() == "1"
            TYPING["ts"] = time.time() if on else 0.0
            return self._json({"ok": True, "typing": on})

        if u.path == "/upload":
            who = (q.get("who", ["老大"])[0]) or "老大"
            kind = (q.get("kind", ["file"])[0]) or "file"
            name = safe_name(q.get("name", ["file"])[0])
            n = int(self.headers.get("Content-Length") or 0)
            ctype = self.headers.get("Content-Type") or ""
            chunked = "chunked" in (self.headers.get("Transfer-Encoding") or "").lower()
            if chunked:
                body = self._read_chunked()
                if body is None:
                    return self._json({"err": "bad chunked body"}, 400)
                if ctype.startswith("multipart/form-data"):
                    data = self._part_file(body, ctype)
                    if data is None:
                        return self._json({"err": "no file part"}, 400)
                else:
                    data = body
                os.makedirs(FILES, exist_ok=True)
                fname = f"{int(time.time())}_{name}"
                path = os.path.join(FILES, fname)
                with open(path, "wb") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                got = os.path.getsize(path)
                if got != len(data):
                    return self._json({"err": "short write", "got": got, "expect": len(data)}, 400)
                if kind == "image":
                    shrink_image(path)
                return self._json(add(who, kind, name=name, url="/files/" + fname))
            if n <= 0 or n > MAX_UP:
                return self._json({"err": "bad size"}, 400)
            os.makedirs(FILES, exist_ok=True)
            stamp = str(int(time.time()))
            fname = f"{stamp}_{name}"
            path = os.path.join(FILES, fname)
            if ctype.startswith("multipart/form-data"):
                body = self.rfile.read(n)
                if len(body) != n:
                    print("upload short body: got %d expect %d" % (len(body), n), flush=True)
                    return self._json({"err": "short body", "got": len(body), "expect": n}, 400)
                data = self._part_file(body, ctype)
                if data is None:
                    return self._json({"err": "no file part"}, 400)
                with open(path, "wb") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                got = os.path.getsize(path)
                if got != len(data):
                    return self._json({"err": "short write", "got": got, "expect": len(data)}, 400)
                if kind == "image":
                    shrink_image(path)
                return self._json(add(who, kind, name=name, url="/files/" + fname))
            left = n
            with open(path, "wb") as f:
                while left > 0:
                    chunk = self.rfile.read(min(65536, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            got = os.path.getsize(path)
            if got != n:
                print("upload short write: got %d expect %d" % (got, n), flush=True)
                return self._json({"err": "short write", "got": got, "expect": n}, 400)
            if kind == "image":
                shrink_image(path)
            m = add(who, kind, name=name, url="/files/" + fname)
            return self._json(m)
        return self._json({"err": "not found"}, 404)


if __name__ == "__main__":
    os.makedirs(FILES, exist_ok=True)
    threading.Thread(target=cost_loop, daemon=True).start()
    port = int(os.environ.get("PORT", "6099"))
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()
